<?php
/**
 * API per la gestione delle cartelle con multi-tenancy
 *
 * Endpoints supportati:
 * - GET: Albero cartelle gerarchico con lazy loading
 * - POST: Creazione nuova cartella
 * - PUT: Rinomina cartella
 * - DELETE: Eliminazione cartella
 * - POST ?action=move: Sposta cartella
 * - POST ?action=copy: Copia cartella
 * - POST ?action=share: Condividi cartella
 * - GET ?action=breadcrumb: Percorso breadcrumb
 * - GET ?action=search: Ricerca cartelle
 * - GET ?action=recent: Cartelle recenti
 */

// PRIMA COSA: Includi session_init.php per configurare sessione correttamente
require_once __DIR__ . '/../includes/session_init.php';


declare(strict_types=1);header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');

require_once '../config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/FileManager.php';

// Authentication validation
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    die(json_encode([
        'success' => false,
        'error' => 'Non autorizzato',
        'code' => 'AUTH_REQUIRED'
    ]));
}

// Tenant isolation
$tenant_id = (int)$_SESSION['tenant_id'];
$user_id = (int)$_SESSION['user_id'];

// Initialize database connection and FileManager
$database = Database::getInstance();
$pdo = $database->getConnection();
$fileManager = new FileManager($pdo, $tenant_id, $user_id);

// Input sanitization
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';
$folder_id = isset($_GET['id']) ? (int)$_GET['id'] : null;

// Generate request ID for tracking
$request_id = bin2hex(random_bytes(8));

/**
 * Helper function to send JSON response
 */
function sendResponse(array $data, int $httpCode = 200): void {
    global $request_id;

    http_response_code($httpCode);

    $response = [
        'success' => $httpCode >= 200 && $httpCode < 300,
        'data' => $data['data'] ?? null,
        'message' => $data['message'] ?? null,
        'metadata' => [
            'timestamp' => date('c'),
            'request_id' => $request_id
        ]
    ];

    if (isset($data['error'])) {
        $response['error'] = $data['error'];
        $response['code'] = $data['code'] ?? 'UNKNOWN_ERROR';
    }

    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * Validate folder name
 */
function validateFolderName(string $name): bool {
    // Permetti lettere, numeri, spazi, trattini e underscore
    return preg_match('/^[a-zA-Z0-9\s\-_]+$/', $name) === 1 &&
           strlen($name) >= 1 &&
           strlen($name) <= 255;
}

/**
 * Check if user has permission on folder
 */
function checkFolderPermission(PDO $pdo, int $folder_id, int $user_id, int $tenant_id, string $permission = 'read'): bool {
    $stmt = $pdo->prepare("
        SELECT f.id, f.created_by,
               fp.can_read, fp.can_write, fp.can_delete, fp.can_share
        FROM folders f
        LEFT JOIN folder_permissions fp ON f.id = fp.folder_id AND fp.user_id = :user_id
        WHERE f.id = :folder_id
        AND f.tenant_id = :tenant_id
        AND f.is_deleted = 0
    ");

    $stmt->execute([
        ':folder_id' => $folder_id,
        ':user_id' => $user_id,
        ':tenant_id' => $tenant_id
    ]);

    $folder = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$folder) {
        return false;
    }

    // Il creatore ha tutti i permessi
    if ($folder['created_by'] == $user_id) {
        return true;
    }

    // Controlla permessi specifici
    switch ($permission) {
        case 'read':
            return $folder['can_read'] == 1;
        case 'write':
            return $folder['can_write'] == 1;
        case 'delete':
            return $folder['can_delete'] == 1;
        case 'share':
            return $folder['can_share'] == 1;
        default:
            return false;
    }
}

/**
 * Update folder statistics (counts and sizes)
 */
function updateFolderStatistics(PDO $pdo, int $folder_id, int $tenant_id): void {
    try {
        // Conta file diretti nella cartella
        $stmt = $pdo->prepare("
            SELECT COUNT(*) as file_count, COALESCE(SUM(size), 0) as total_size
            FROM files
            WHERE folder_id = :folder_id AND tenant_id = :tenant_id
        ");
        $stmt->execute([':folder_id' => $folder_id, ':tenant_id' => $tenant_id]);
        $fileStats = $stmt->fetch(PDO::FETCH_ASSOC);

        // Conta sottocartelle dirette
        $stmt = $pdo->prepare("
            SELECT COUNT(*) as folder_count
            FROM folders
            WHERE parent_id = :folder_id
            AND tenant_id = :tenant_id
            AND is_deleted = 0
        ");
        $stmt->execute([':folder_id' => $folder_id, ':tenant_id' => $tenant_id]);
        $folderStats = $stmt->fetch(PDO::FETCH_ASSOC);

        // Aggiorna statistiche
        $stmt = $pdo->prepare("
            UPDATE folders
            SET file_count = :file_count,
                folder_count = :folder_count,
                total_size = :total_size,
                updated_at = NOW()
            WHERE id = :folder_id AND tenant_id = :tenant_id
        ");

        $stmt->execute([
            ':file_count' => $fileStats['file_count'],
            ':folder_count' => $folderStats['folder_count'],
            ':total_size' => $fileStats['total_size'],
            ':folder_id' => $folder_id,
            ':tenant_id' => $tenant_id
        ]);
    } catch (Exception $e) {
        error_log("Error updating folder statistics: " . $e->getMessage());
    }
}

/**
 * Build folder tree recursively
 */
function buildFolderTree(PDO $pdo, int $tenant_id, int $user_id, ?int $parent_id = null, int $depth = 1, int $max_depth = 3, array $expanded = []): array {
    if ($depth > $max_depth) {
        return [];
    }

    $query = "
        SELECT f.*,
               (SELECT COUNT(*) FROM folders
                WHERE parent_id = f.id
                AND tenant_id = f.tenant_id
                AND is_deleted = 0) as has_children
        FROM folders f
        WHERE f.tenant_id = :tenant_id
        AND f.is_deleted = 0
    ";

    if ($parent_id === null) {
        $query .= " AND f.parent_id IS NULL";
    } else {
        $query .= " AND f.parent_id = :parent_id";
    }

    $query .= " ORDER BY f.name ASC";

    $stmt = $pdo->prepare($query);

    $params = [':tenant_id' => $tenant_id];
    if ($parent_id !== null) {
        $params[':parent_id'] = $parent_id;
    }

    $stmt->execute($params);
    $folders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $tree = [];
    foreach ($folders as $folder) {
        $node = [
            'id' => $folder['id'],
            'name' => $folder['name'],
            'path' => $folder['path'],
            'parent_id' => $folder['parent_id'],
            'has_children' => $folder['has_children'] > 0,
            'file_count' => $folder['file_count'],
            'folder_count' => $folder['folder_count'],
            'total_size' => $folder['total_size'],
            'created_at' => $folder['created_at'],
            'updated_at' => $folder['updated_at']
        ];

        // Load children if folder is expanded or within depth limit
        if (in_array($folder['id'], $expanded) || $depth < $max_depth) {
            $node['children'] = buildFolderTree($pdo, $tenant_id, $user_id, $folder['id'], $depth + 1, $max_depth, $expanded);
        } else if ($folder['has_children'] > 0) {
            $node['children'] = null; // Indica che ci sono figli non caricati
        }

        $tree[] = $node;
    }

    return $tree;
}

try {
    // Main request router
    switch ($method) {
        case 'GET':
            if ($action === 'breadcrumb') {
                // GET ?action=breadcrumb&id=X - Return breadcrumb path
                if (!$folder_id) {
                    sendResponse(['error' => 'ID cartella richiesto', 'code' => 'MISSING_FOLDER_ID'], 400);
                }

                if (!checkFolderPermission($pdo, $folder_id, $user_id, $tenant_id, 'read')) {
                    sendResponse(['error' => 'Accesso negato', 'code' => 'ACCESS_DENIED'], 403);
                }

                // Build breadcrumb using path column or recursive query
                $breadcrumb = [];
                $current_id = $folder_id;

                while ($current_id !== null) {
                    $stmt = $pdo->prepare("
                        SELECT id, name, parent_id, path
                        FROM folders
                        WHERE id = :id
                        AND tenant_id = :tenant_id
                        AND is_deleted = 0
                    ");

                    $stmt->execute([
                        ':id' => $current_id,
                        ':tenant_id' => $tenant_id
                    ]);

                    $folder = $stmt->fetch(PDO::FETCH_ASSOC);

                    if (!$folder) {
                        break;
                    }

                    array_unshift($breadcrumb, [
                        'id' => $folder['id'],
                        'name' => $folder['name'],
                        'path' => $folder['path']
                    ]);

                    $current_id = $folder['parent_id'];
                }

                // Add root
                array_unshift($breadcrumb, [
                    'id' => null,
                    'name' => 'Home',
                    'path' => '/'
                ]);

                sendResponse(['data' => $breadcrumb]);

            } elseif ($action === 'search') {
                // GET ?action=search&q=term&parent_id=X&limit=10
                $search_term = $_GET['q'] ?? '';
                $parent_id = isset($_GET['parent_id']) ? (int)$_GET['parent_id'] : null;
                $limit = min(100, max(1, (int)($_GET['limit'] ?? 10)));

                if (strlen($search_term) < 2) {
                    sendResponse(['error' => 'Termine di ricerca troppo corto', 'code' => 'SEARCH_TERM_TOO_SHORT'], 400);
                }

                $query = "
                    SELECT id, name, path, parent_id, file_count, folder_count, total_size
                    FROM folders
                    WHERE tenant_id = :tenant_id
                    AND is_deleted = 0
                    AND name LIKE :search_term
                ";

                $params = [
                    ':tenant_id' => $tenant_id,
                    ':search_term' => '%' . $search_term . '%'
                ];

                if ($parent_id !== null) {
                    $query .= " AND (parent_id = :parent_id OR path LIKE :parent_path)";

                    // Get parent path
                    $stmt = $pdo->prepare("SELECT path FROM folders WHERE id = :id AND tenant_id = :tenant_id");
                    $stmt->execute([':id' => $parent_id, ':tenant_id' => $tenant_id]);
                    $parent_folder = $stmt->fetch(PDO::FETCH_ASSOC);

                    if ($parent_folder) {
                        $params[':parent_id'] = $parent_id;
                        $params[':parent_path'] = $parent_folder['path'] . '/%';
                    }
                }

                $query .= " ORDER BY name ASC LIMIT :limit";

                $stmt = $pdo->prepare($query);
                foreach ($params as $key => $value) {
                    $stmt->bindValue($key, $value);
                }
                $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
                $stmt->execute();

                $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

                sendResponse(['data' => $results]);

            } elseif ($action === 'recent') {
                // GET ?action=recent&limit=10
                $limit = min(50, max(1, (int)($_GET['limit'] ?? 10)));

                // Get recently accessed folders from activity log
                $stmt = $pdo->prepare("
                    SELECT DISTINCT f.id, f.name, f.path, f.parent_id,
                           f.file_count, f.folder_count, f.total_size,
                           MAX(al.created_at) as last_accessed
                    FROM folders f
                    INNER JOIN activity_logs al ON f.id = al.folder_id
                    WHERE f.tenant_id = :tenant_id
                    AND f.is_deleted = 0
                    AND al.user_id = :user_id
                    AND al.action IN ('view', 'upload', 'download')
                    AND al.created_at > DATE_SUB(NOW(), INTERVAL 30 DAY)
                    GROUP BY f.id
                    ORDER BY last_accessed DESC
                    LIMIT :limit
                ");

                $stmt->bindValue(':tenant_id', $tenant_id, PDO::PARAM_INT);
                $stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
                $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
                $stmt->execute();

                $recent = $stmt->fetchAll(PDO::FETCH_ASSOC);

                sendResponse(['data' => $recent]);

            } else {
                // GET - Folder tree
                $parent_id = isset($_GET['parent_id']) ? (int)$_GET['parent_id'] : null;
                $depth = min(5, max(1, (int)($_GET['depth'] ?? 3)));
                $include_counts = filter_var($_GET['include_counts'] ?? true, FILTER_VALIDATE_BOOLEAN);
                $include_sizes = filter_var($_GET['include_sizes'] ?? false, FILTER_VALIDATE_BOOLEAN);
                $expanded = isset($_GET['expanded']) ? array_map('intval', (array)$_GET['expanded']) : [];

                // Build folder tree
                $tree = buildFolderTree($pdo, $tenant_id, $user_id, $parent_id, 1, $depth, $expanded);

                // Calculate totals if requested
                $totals = null;
                if ($include_counts || $include_sizes) {
                    $stmt = $pdo->prepare("
                        SELECT COUNT(*) as total_folders,
                               SUM(file_count) as total_files,
                               SUM(total_size) as total_size
                        FROM folders
                        WHERE tenant_id = :tenant_id
                        AND is_deleted = 0
                    ");
                    $stmt->execute([':tenant_id' => $tenant_id]);
                    $totals = $stmt->fetch(PDO::FETCH_ASSOC);
                }

                $response = ['folders' => $tree];
                if ($totals) {
                    $response['totals'] = $totals;
                }

                sendResponse(['data' => $response]);
            }
            break;

        case 'POST':
            if ($action === 'move') {
                // POST ?action=move - Move folder
                $input = json_decode(file_get_contents('php://input'), true);
                $source_id = (int)($input['source_id'] ?? 0);
                $target_id = $input['target_id'] !== null ? (int)$input['target_id'] : null;

                if (!$source_id) {
                    sendResponse(['error' => 'ID cartella sorgente richiesto', 'code' => 'MISSING_SOURCE_ID'], 400);
                }

                // Check permissions
                if (!checkFolderPermission($pdo, $source_id, $user_id, $tenant_id, 'write')) {
                    sendResponse(['error' => 'Permessi insufficienti sulla cartella sorgente', 'code' => 'ACCESS_DENIED'], 403);
                }

                if ($target_id !== null && !checkFolderPermission($pdo, $target_id, $user_id, $tenant_id, 'write')) {
                    sendResponse(['error' => 'Permessi insufficienti sulla cartella di destinazione', 'code' => 'ACCESS_DENIED'], 403);
                }

                // Prevent circular references
                if ($target_id !== null) {
                    $current = $target_id;
                    while ($current !== null) {
                        if ($current == $source_id) {
                            sendResponse(['error' => 'Impossibile spostare una cartella in se stessa o in una sua sottocartella', 'code' => 'CIRCULAR_REFERENCE'], 400);
                        }

                        $stmt = $pdo->prepare("SELECT parent_id FROM folders WHERE id = :id AND tenant_id = :tenant_id");
                        $stmt->execute([':id' => $current, ':tenant_id' => $tenant_id]);
                        $parent = $stmt->fetch(PDO::FETCH_ASSOC);
                        $current = $parent ? $parent['parent_id'] : null;
                    }
                }

                // Start transaction
                $pdo->beginTransaction();

                try {
                    // Get source folder info
                    $stmt = $pdo->prepare("SELECT * FROM folders WHERE id = :id AND tenant_id = :tenant_id");
                    $stmt->execute([':id' => $source_id, ':tenant_id' => $tenant_id]);
                    $source = $stmt->fetch(PDO::FETCH_ASSOC);

                    if (!$source) {
                        throw new Exception('Cartella sorgente non trovata');
                    }

                    // Build new path
                    $new_path = '';
                    if ($target_id !== null) {
                        $stmt = $pdo->prepare("SELECT path FROM folders WHERE id = :id AND tenant_id = :tenant_id");
                        $stmt->execute([':id' => $target_id, ':tenant_id' => $tenant_id]);
                        $target = $stmt->fetch(PDO::FETCH_ASSOC);

                        if (!$target) {
                            throw new Exception('Cartella di destinazione non trovata');
                        }

                        $new_path = $target['path'] . '/' . $source['name'];
                    } else {
                        $new_path = '/' . $source['name'];
                    }

                    // Update source folder
                    $stmt = $pdo->prepare("
                        UPDATE folders
                        SET parent_id = :parent_id,
                            path = :path,
                            updated_at = NOW()
                        WHERE id = :id AND tenant_id = :tenant_id
                    ");

                    $stmt->execute([
                        ':parent_id' => $target_id,
                        ':path' => $new_path,
                        ':id' => $source_id,
                        ':tenant_id' => $tenant_id
                    ]);

                    // Update all descendant paths
                    $old_path = $source['path'];
                    $stmt = $pdo->prepare("
                        UPDATE folders
                        SET path = CONCAT(:new_path, SUBSTRING(path, :old_path_len + 1)),
                            updated_at = NOW()
                        WHERE tenant_id = :tenant_id
                        AND path LIKE :old_path_pattern
                    ");

                    $stmt->execute([
                        ':new_path' => $new_path,
                        ':old_path_len' => strlen($old_path),
                        ':tenant_id' => $tenant_id,
                        ':old_path_pattern' => $old_path . '/%'
                    ]);

                    $affected_folders = $stmt->rowCount();

                    // Update statistics for old and new parent
                    if ($source['parent_id']) {
                        updateFolderStatistics($pdo, $source['parent_id'], $tenant_id);
                    }
                    if ($target_id) {
                        updateFolderStatistics($pdo, $target_id, $tenant_id);
                    }

                    // Log activity
                    $stmt = $pdo->prepare("
                        INSERT INTO activity_logs (tenant_id, user_id, action, entity_type, entity_id, details, created_at)
                        VALUES (:tenant_id, :user_id, 'move', 'folder', :folder_id, :details, NOW())
                    ");

                    $stmt->execute([
                        ':tenant_id' => $tenant_id,
                        ':user_id' => $user_id,
                        ':folder_id' => $source_id,
                        ':details' => json_encode([
                            'from_parent' => $source['parent_id'],
                            'to_parent' => $target_id,
                            'affected_folders' => $affected_folders
                        ])
                    ]);

                    $pdo->commit();

                    sendResponse([
                        'data' => [
                            'moved_folder_id' => $source_id,
                            'new_parent_id' => $target_id,
                            'new_path' => $new_path,
                            'affected_folders' => $affected_folders
                        ],
                        'message' => 'Cartella spostata con successo'
                    ]);

                } catch (Exception $e) {
                    $pdo->rollBack();
                    throw $e;
                }

            } elseif ($action === 'copy') {
                // POST ?action=copy - Deep copy folder
                $input = json_decode(file_get_contents('php://input'), true);
                $source_id = (int)($input['source_id'] ?? 0);
                $target_id = $input['target_id'] !== null ? (int)$input['target_id'] : null;
                $include_files = filter_var($input['include_files'] ?? true, FILTER_VALIDATE_BOOLEAN);
                $new_name = trim($input['new_name'] ?? '');

                if (!$source_id) {
                    sendResponse(['error' => 'ID cartella sorgente richiesto', 'code' => 'MISSING_SOURCE_ID'], 400);
                }

                if (!checkFolderPermission($pdo, $source_id, $user_id, $tenant_id, 'read')) {
                    sendResponse(['error' => 'Permessi insufficienti sulla cartella sorgente', 'code' => 'ACCESS_DENIED'], 403);
                }

                if ($target_id !== null && !checkFolderPermission($pdo, $target_id, $user_id, $tenant_id, 'write')) {
                    sendResponse(['error' => 'Permessi insufficienti sulla cartella di destinazione', 'code' => 'ACCESS_DENIED'], 403);
                }

                $pdo->beginTransaction();

                try {
                    // Function to recursively copy folder
                    $copyFolder = function($source_folder_id, $new_parent_id, $new_folder_name = null) use ($pdo, $tenant_id, $user_id, $include_files, &$copyFolder) {
                        // Get source folder
                        $stmt = $pdo->prepare("SELECT * FROM folders WHERE id = :id AND tenant_id = :tenant_id");
                        $stmt->execute([':id' => $source_folder_id, ':tenant_id' => $tenant_id]);
                        $source = $stmt->fetch(PDO::FETCH_ASSOC);

                        if (!$source) {
                            throw new Exception('Cartella sorgente non trovata');
                        }

                        // Determine new name
                        $folder_name = $new_folder_name ?: $source['name'];

                        // Check for duplicate and generate unique name if needed
                        $base_name = $folder_name;
                        $counter = 1;
                        while (true) {
                            $stmt = $pdo->prepare("
                                SELECT id FROM folders
                                WHERE parent_id " . ($new_parent_id ? "= :parent_id" : "IS NULL") . "
                                AND name = :name
                                AND tenant_id = :tenant_id
                                AND is_deleted = 0
                            ");

                            $params = [':name' => $folder_name, ':tenant_id' => $tenant_id];
                            if ($new_parent_id) {
                                $params[':parent_id'] = $new_parent_id;
                            }

                            $stmt->execute($params);

                            if (!$stmt->fetch()) {
                                break;
                            }

                            $folder_name = $base_name . ' (' . $counter . ')';
                            $counter++;
                        }

                        // Build new path
                        $new_path = '';
                        if ($new_parent_id !== null) {
                            $stmt = $pdo->prepare("SELECT path FROM folders WHERE id = :id AND tenant_id = :tenant_id");
                            $stmt->execute([':id' => $new_parent_id, ':tenant_id' => $tenant_id]);
                            $parent = $stmt->fetch(PDO::FETCH_ASSOC);

                            if ($parent) {
                                $new_path = $parent['path'] . '/' . $folder_name;
                            }
                        } else {
                            $new_path = '/' . $folder_name;
                        }

                        // Create new folder
                        $stmt = $pdo->prepare("
                            INSERT INTO folders (tenant_id, parent_id, name, path, created_by, created_at, updated_at)
                            VALUES (:tenant_id, :parent_id, :name, :path, :user_id, NOW(), NOW())
                        ");

                        $stmt->execute([
                            ':tenant_id' => $tenant_id,
                            ':parent_id' => $new_parent_id,
                            ':name' => $folder_name,
                            ':path' => $new_path,
                            ':user_id' => $user_id
                        ]);

                        $new_folder_id = $pdo->lastInsertId();

                        // Copy files if requested
                        if ($include_files) {
                            $stmt = $pdo->prepare("
                                SELECT * FROM files
                                WHERE folder_id = :folder_id
                                AND tenant_id = :tenant_id
                            ");
                            $stmt->execute([
                                ':folder_id' => $source_folder_id,
                                ':tenant_id' => $tenant_id
                            ]);

                            $files = $stmt->fetchAll(PDO::FETCH_ASSOC);

                            foreach ($files as $file) {
                                // Create file reference (deduplication)
                                $stmt = $pdo->prepare("
                                    INSERT INTO file_references (
                                        tenant_id, file_id, folder_id, user_id,
                                        original_name, created_at
                                    ) VALUES (
                                        :tenant_id, :file_id, :folder_id, :user_id,
                                        :original_name, NOW()
                                    )
                                ");

                                $stmt->execute([
                                    ':tenant_id' => $tenant_id,
                                    ':file_id' => $file['id'],
                                    ':folder_id' => $new_folder_id,
                                    ':user_id' => $user_id,
                                    ':original_name' => $file['original_name']
                                ]);
                            }
                        }

                        // Recursively copy subfolders
                        $stmt = $pdo->prepare("
                            SELECT id FROM folders
                            WHERE parent_id = :parent_id
                            AND tenant_id = :tenant_id
                            AND is_deleted = 0
                        ");
                        $stmt->execute([
                            ':parent_id' => $source_folder_id,
                            ':tenant_id' => $tenant_id
                        ]);

                        $subfolders = $stmt->fetchAll(PDO::FETCH_ASSOC);

                        foreach ($subfolders as $subfolder) {
                            $copyFolder($subfolder['id'], $new_folder_id);
                        }

                        return $new_folder_id;
                    };

                    $new_folder_id = $copyFolder($source_id, $target_id, $new_name);

                    // Update statistics
                    updateFolderStatistics($pdo, $new_folder_id, $tenant_id);
                    if ($target_id) {
                        updateFolderStatistics($pdo, $target_id, $tenant_id);
                    }

                    // Log activity
                    $stmt = $pdo->prepare("
                        INSERT INTO activity_logs (tenant_id, user_id, action, entity_type, entity_id, details, created_at)
                        VALUES (:tenant_id, :user_id, 'copy', 'folder', :folder_id, :details, NOW())
                    ");

                    $stmt->execute([
                        ':tenant_id' => $tenant_id,
                        ':user_id' => $user_id,
                        ':folder_id' => $new_folder_id,
                        ':details' => json_encode([
                            'source_id' => $source_id,
                            'include_files' => $include_files
                        ])
                    ]);

                    $pdo->commit();

                    sendResponse([
                        'data' => [
                            'new_folder_id' => $new_folder_id,
                            'parent_id' => $target_id
                        ],
                        'message' => 'Cartella copiata con successo'
                    ]);

                } catch (Exception $e) {
                    $pdo->rollBack();
                    throw $e;
                }

            } elseif ($action === 'share') {
                // POST ?action=share - Share folder with users
                $input = json_decode(file_get_contents('php://input'), true);
                $folder_id = (int)($input['folder_id'] ?? 0);
                $user_ids = array_map('intval', (array)($input['user_ids'] ?? []));
                $permissions = $input['permissions'] ?? ['read' => true];
                $inherit_to_subfolders = filter_var($input['inherit_to_subfolders'] ?? false, FILTER_VALIDATE_BOOLEAN);

                if (!$folder_id || empty($user_ids)) {
                    sendResponse(['error' => 'Parametri mancanti', 'code' => 'MISSING_PARAMETERS'], 400);
                }

                if (!checkFolderPermission($pdo, $folder_id, $user_id, $tenant_id, 'share')) {
                    sendResponse(['error' => 'Permessi insufficienti per condividere', 'code' => 'ACCESS_DENIED'], 403);
                }

                $pdo->beginTransaction();

                try {
                    // Get folders to share (including subfolders if requested)
                    $folders_to_share = [$folder_id];

                    if ($inherit_to_subfolders) {
                        $stmt = $pdo->prepare("
                            SELECT id FROM folders
                            WHERE tenant_id = :tenant_id
                            AND is_deleted = 0
                            AND path LIKE (
                                SELECT CONCAT(path, '/%')
                                FROM folders
                                WHERE id = :folder_id
                                AND tenant_id = :tenant_id2
                            )
                        ");

                        $stmt->execute([
                            ':tenant_id' => $tenant_id,
                            ':tenant_id2' => $tenant_id,
                            ':folder_id' => $folder_id
                        ]);

                        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                            $folders_to_share[] = $row['id'];
                        }
                    }

                    // Share with each user
                    foreach ($user_ids as $share_user_id) {
                        // Verify user exists in tenant
                        $stmt = $pdo->prepare("
                            SELECT id FROM users
                            WHERE id = :user_id
                            AND tenant_id = :tenant_id
                        ");
                        $stmt->execute([
                            ':user_id' => $share_user_id,
                            ':tenant_id' => $tenant_id
                        ]);

                        if (!$stmt->fetch()) {
                            continue; // Skip non-existent users
                        }

                        foreach ($folders_to_share as $share_folder_id) {
                            // Remove existing permissions
                            $stmt = $pdo->prepare("
                                DELETE FROM folder_permissions
                                WHERE folder_id = :folder_id
                                AND user_id = :user_id
                            ");
                            $stmt->execute([
                                ':folder_id' => $share_folder_id,
                                ':user_id' => $share_user_id
                            ]);

                            // Add new permissions
                            $stmt = $pdo->prepare("
                                INSERT INTO folder_permissions (
                                    folder_id, user_id, can_read, can_write,
                                    can_delete, can_share, created_at
                                ) VALUES (
                                    :folder_id, :user_id, :can_read, :can_write,
                                    :can_delete, :can_share, NOW()
                                )
                            ");

                            $stmt->execute([
                                ':folder_id' => $share_folder_id,
                                ':user_id' => $share_user_id,
                                ':can_read' => isset($permissions['read']) && $permissions['read'] ? 1 : 0,
                                ':can_write' => isset($permissions['write']) && $permissions['write'] ? 1 : 0,
                                ':can_delete' => isset($permissions['delete']) && $permissions['delete'] ? 1 : 0,
                                ':can_share' => isset($permissions['share']) && $permissions['share'] ? 1 : 0
                            ]);
                        }
                    }

                    // Log activity
                    $stmt = $pdo->prepare("
                        INSERT INTO activity_logs (tenant_id, user_id, action, entity_type, entity_id, details, created_at)
                        VALUES (:tenant_id, :user_id, 'share', 'folder', :folder_id, :details, NOW())
                    ");

                    $stmt->execute([
                        ':tenant_id' => $tenant_id,
                        ':user_id' => $user_id,
                        ':folder_id' => $folder_id,
                        ':details' => json_encode([
                            'shared_with' => $user_ids,
                            'permissions' => $permissions,
                            'inherit_to_subfolders' => $inherit_to_subfolders,
                            'total_folders_shared' => count($folders_to_share)
                        ])
                    ]);

                    $pdo->commit();

                    sendResponse([
                        'data' => [
                            'shared_folder_id' => $folder_id,
                            'shared_with_users' => $user_ids,
                            'folders_affected' => count($folders_to_share)
                        ],
                        'message' => 'Cartella condivisa con successo'
                    ]);

                } catch (Exception $e) {
                    $pdo->rollBack();
                    throw $e;
                }

            } else {
                // POST - Create new folder
                $input = json_decode(file_get_contents('php://input'), true);
                $folder_name = trim($input['name'] ?? '');
                $parent_id = isset($input['parent_id']) ? (int)$input['parent_id'] : null;
                $create_parents = filter_var($input['create_parents'] ?? false, FILTER_VALIDATE_BOOLEAN);

                if (!validateFolderName($folder_name)) {
                    sendResponse(['error' => 'Nome cartella non valido', 'code' => 'INVALID_FOLDER_NAME'], 400);
                }

                // Check parent permissions if specified
                if ($parent_id !== null && !checkFolderPermission($pdo, $parent_id, $user_id, $tenant_id, 'write')) {
                    sendResponse(['error' => 'Permessi insufficienti sulla cartella padre', 'code' => 'ACCESS_DENIED'], 403);
                }

                $pdo->beginTransaction();

                try {
                    // Check for duplicates
                    $stmt = $pdo->prepare("
                        SELECT id FROM folders
                        WHERE tenant_id = :tenant_id
                        AND parent_id " . ($parent_id ? "= :parent_id" : "IS NULL") . "
                        AND name = :name
                        AND is_deleted = 0
                    ");

                    $params = [':tenant_id' => $tenant_id, ':name' => $folder_name];
                    if ($parent_id) {
                        $params[':parent_id'] = $parent_id;
                    }

                    $stmt->execute($params);

                    if ($stmt->fetch()) {
                        throw new Exception('Una cartella con questo nome esiste già in questa posizione');
                    }

                    // Build path
                    $path = '';
                    if ($parent_id) {
                        $stmt = $pdo->prepare("
                            SELECT path FROM folders
                            WHERE id = :id
                            AND tenant_id = :tenant_id
                        ");
                        $stmt->execute([':id' => $parent_id, ':tenant_id' => $tenant_id]);
                        $parent = $stmt->fetch(PDO::FETCH_ASSOC);

                        if (!$parent) {
                            throw new Exception('Cartella padre non trovata');
                        }

                        $path = $parent['path'] . '/' . $folder_name;
                    } else {
                        $path = '/' . $folder_name;
                    }

                    // Create folder
                    $stmt = $pdo->prepare("
                        INSERT INTO folders (
                            tenant_id, parent_id, name, path,
                            created_by, created_at, updated_at,
                            file_count, folder_count, total_size
                        ) VALUES (
                            :tenant_id, :parent_id, :name, :path,
                            :user_id, NOW(), NOW(),
                            0, 0, 0
                        )
                    ");

                    $stmt->execute([
                        ':tenant_id' => $tenant_id,
                        ':parent_id' => $parent_id,
                        ':name' => $folder_name,
                        ':path' => $path,
                        ':user_id' => $user_id
                    ]);

                    $new_folder_id = $pdo->lastInsertId();

                    // Update parent statistics
                    if ($parent_id) {
                        updateFolderStatistics($pdo, $parent_id, $tenant_id);
                    }

                    // Create physical directory if using filesystem
                    try {
                        $fileManager->createFolder($path);
                    } catch (Exception $e) {
                        // Log but don't fail if physical creation fails
                        error_log("Failed to create physical folder: " . $e->getMessage());
                    }

                    // Log activity
                    $stmt = $pdo->prepare("
                        INSERT INTO activity_logs (tenant_id, user_id, action, entity_type, entity_id, details, created_at)
                        VALUES (:tenant_id, :user_id, 'create', 'folder', :folder_id, :details, NOW())
                    ");

                    $stmt->execute([
                        ':tenant_id' => $tenant_id,
                        ':user_id' => $user_id,
                        ':folder_id' => $new_folder_id,
                        ':details' => json_encode(['name' => $folder_name, 'path' => $path])
                    ]);

                    $pdo->commit();

                    sendResponse([
                        'data' => [
                            'id' => $new_folder_id,
                            'name' => $folder_name,
                            'path' => $path,
                            'parent_id' => $parent_id
                        ],
                        'message' => 'Cartella creata con successo'
                    ], 201);

                } catch (Exception $e) {
                    $pdo->rollBack();
                    throw $e;
                }
            }
            break;

        case 'PUT':
            // PUT ?id=X - Rename folder
            if (!$folder_id) {
                sendResponse(['error' => 'ID cartella richiesto', 'code' => 'MISSING_FOLDER_ID'], 400);
            }

            $input = json_decode(file_get_contents('php://input'), true);
            $new_name = trim($input['name'] ?? '');

            if (!validateFolderName($new_name)) {
                sendResponse(['error' => 'Nome cartella non valido', 'code' => 'INVALID_FOLDER_NAME'], 400);
            }

            if (!checkFolderPermission($pdo, $folder_id, $user_id, $tenant_id, 'write')) {
                sendResponse(['error' => 'Permessi insufficienti', 'code' => 'ACCESS_DENIED'], 403);
            }

            $pdo->beginTransaction();

            try {
                // Get current folder info
                $stmt = $pdo->prepare("
                    SELECT * FROM folders
                    WHERE id = :id
                    AND tenant_id = :tenant_id
                    AND is_deleted = 0
                ");
                $stmt->execute([':id' => $folder_id, ':tenant_id' => $tenant_id]);
                $folder = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$folder) {
                    throw new Exception('Cartella non trovata');
                }

                // Check for duplicate name in same parent
                $stmt = $pdo->prepare("
                    SELECT id FROM folders
                    WHERE tenant_id = :tenant_id
                    AND parent_id " . ($folder['parent_id'] ? "= :parent_id" : "IS NULL") . "
                    AND name = :name
                    AND id != :current_id
                    AND is_deleted = 0
                ");

                $params = [
                    ':tenant_id' => $tenant_id,
                    ':name' => $new_name,
                    ':current_id' => $folder_id
                ];
                if ($folder['parent_id']) {
                    $params[':parent_id'] = $folder['parent_id'];
                }

                $stmt->execute($params);

                if ($stmt->fetch()) {
                    throw new Exception('Una cartella con questo nome esiste già in questa posizione');
                }

                // Calculate new path
                $old_path = $folder['path'];
                $path_parts = explode('/', $old_path);
                $path_parts[count($path_parts) - 1] = $new_name;
                $new_path = implode('/', $path_parts);

                // Update folder
                $stmt = $pdo->prepare("
                    UPDATE folders
                    SET name = :name,
                        path = :path,
                        updated_at = NOW()
                    WHERE id = :id
                    AND tenant_id = :tenant_id
                ");

                $stmt->execute([
                    ':name' => $new_name,
                    ':path' => $new_path,
                    ':id' => $folder_id,
                    ':tenant_id' => $tenant_id
                ]);

                // Update all descendant paths
                $stmt = $pdo->prepare("
                    UPDATE folders
                    SET path = CONCAT(:new_path, SUBSTRING(path, :old_path_len + 1)),
                        updated_at = NOW()
                    WHERE tenant_id = :tenant_id
                    AND path LIKE :old_path_pattern
                ");

                $stmt->execute([
                    ':new_path' => $new_path,
                    ':old_path_len' => strlen($old_path),
                    ':tenant_id' => $tenant_id,
                    ':old_path_pattern' => $old_path . '/%'
                ]);

                // Log activity
                $stmt = $pdo->prepare("
                    INSERT INTO activity_logs (tenant_id, user_id, action, entity_type, entity_id, details, created_at)
                    VALUES (:tenant_id, :user_id, 'rename', 'folder', :folder_id, :details, NOW())
                ");

                $stmt->execute([
                    ':tenant_id' => $tenant_id,
                    ':user_id' => $user_id,
                    ':folder_id' => $folder_id,
                    ':details' => json_encode([
                        'old_name' => $folder['name'],
                        'new_name' => $new_name
                    ])
                ]);

                $pdo->commit();

                sendResponse([
                    'data' => [
                        'id' => $folder_id,
                        'name' => $new_name,
                        'path' => $new_path
                    ],
                    'message' => 'Cartella rinominata con successo'
                ]);

            } catch (Exception $e) {
                $pdo->rollBack();
                throw $e;
            }
            break;

        case 'DELETE':
            // DELETE ?id=X - Delete folder
            if (!$folder_id) {
                sendResponse(['error' => 'ID cartella richiesto', 'code' => 'MISSING_FOLDER_ID'], 400);
            }

            $force = filter_var($_GET['force'] ?? false, FILTER_VALIDATE_BOOLEAN);

            if (!checkFolderPermission($pdo, $folder_id, $user_id, $tenant_id, 'delete')) {
                sendResponse(['error' => 'Permessi insufficienti', 'code' => 'ACCESS_DENIED'], 403);
            }

            $pdo->beginTransaction();

            try {
                // Get folder info
                $stmt = $pdo->prepare("
                    SELECT * FROM folders
                    WHERE id = :id
                    AND tenant_id = :tenant_id
                    AND is_deleted = 0
                ");
                $stmt->execute([':id' => $folder_id, ':tenant_id' => $tenant_id]);
                $folder = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$folder) {
                    throw new Exception('Cartella non trovata');
                }

                // Check if folder is empty
                if (!$force) {
                    // Check for files
                    $stmt = $pdo->prepare("
                        SELECT COUNT(*) as count
                        FROM files
                        WHERE folder_id = :folder_id
                        AND tenant_id = :tenant_id
                    ");
                    $stmt->execute([':folder_id' => $folder_id, ':tenant_id' => $tenant_id]);
                    $fileCount = $stmt->fetch(PDO::FETCH_ASSOC);

                    if ($fileCount['count'] > 0) {
                        throw new Exception('La cartella contiene file. Usa force=true per eliminare comunque.');
                    }

                    // Check for subfolders
                    $stmt = $pdo->prepare("
                        SELECT COUNT(*) as count
                        FROM folders
                        WHERE parent_id = :parent_id
                        AND tenant_id = :tenant_id
                        AND is_deleted = 0
                    ");
                    $stmt->execute([':parent_id' => $folder_id, ':tenant_id' => $tenant_id]);
                    $folderCount = $stmt->fetch(PDO::FETCH_ASSOC);

                    if ($folderCount['count'] > 0) {
                        throw new Exception('La cartella contiene sottocartelle. Usa force=true per eliminare comunque.');
                    }
                }

                // Soft delete folder and all descendants
                $stmt = $pdo->prepare("
                    UPDATE folders
                    SET is_deleted = 1,
                        deleted_at = NOW(),
                        deleted_by = :user_id
                    WHERE tenant_id = :tenant_id
                    AND (id = :folder_id OR path LIKE :path_pattern)
                ");

                $stmt->execute([
                    ':user_id' => $user_id,
                    ':tenant_id' => $tenant_id,
                    ':folder_id' => $folder_id,
                    ':path_pattern' => $folder['path'] . '/%'
                ]);

                $deleted_folders = $stmt->rowCount();

                // Mark files as deleted if force delete
                if ($force) {
                    $stmt = $pdo->prepare("
                        UPDATE files f
                        INNER JOIN folders fld ON f.folder_id = fld.id
                        SET f.is_deleted = 1,
                            f.deleted_at = NOW()
                        WHERE fld.tenant_id = :tenant_id
                        AND (fld.id = :folder_id OR fld.path LIKE :path_pattern)
                    ");

                    $stmt->execute([
                        ':tenant_id' => $tenant_id,
                        ':folder_id' => $folder_id,
                        ':path_pattern' => $folder['path'] . '/%'
                    ]);
                }

                // Update parent statistics
                if ($folder['parent_id']) {
                    updateFolderStatistics($pdo, $folder['parent_id'], $tenant_id);
                }

                // Log activity
                $stmt = $pdo->prepare("
                    INSERT INTO activity_logs (tenant_id, user_id, action, entity_type, entity_id, details, created_at)
                    VALUES (:tenant_id, :user_id, 'delete', 'folder', :folder_id, :details, NOW())
                ");

                $stmt->execute([
                    ':tenant_id' => $tenant_id,
                    ':user_id' => $user_id,
                    ':folder_id' => $folder_id,
                    ':details' => json_encode([
                        'name' => $folder['name'],
                        'path' => $folder['path'],
                        'forced' => $force,
                        'deleted_folders' => $deleted_folders
                    ])
                ]);

                $pdo->commit();

                sendResponse([
                    'data' => [
                        'deleted_folder_id' => $folder_id,
                        'deleted_folders_count' => $deleted_folders
                    ],
                    'message' => 'Cartella eliminata con successo'
                ]);

            } catch (Exception $e) {
                $pdo->rollBack();
                throw $e;
            }
            break;

        default:
            sendResponse(['error' => 'Metodo non supportato', 'code' => 'METHOD_NOT_ALLOWED'], 405);
    }

} catch (Exception $e) {
    error_log('Folders API Error: ' . $e->getMessage());
    sendResponse([
        'error' => 'Errore del server',
        'code' => 'SERVER_ERROR',
        'message' => $e->getMessage() // In production, remove this line
    ], 500);
}