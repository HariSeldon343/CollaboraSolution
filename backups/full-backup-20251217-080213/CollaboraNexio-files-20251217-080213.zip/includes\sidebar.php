<?php
/**
 * CollaboraNexio - Sidebar Navigation Component (CSS Mask Icons)
 * Include questo file in tutte le pagine per avere una sidebar consistente
 * Integrato con sistema di Page Visibility per controllo accesso basato su ruolo
 */

// Ottieni il nome del file corrente per evidenziare la voce attiva
$current_page = basename($_SERVER['PHP_SELF']);

// Get current user info (should be available from auth)
$currentUser = $currentUser ?? $_SESSION['user'] ?? ['name' => 'Utente', 'role' => 'user'];

// Include page visibility helper
require_once __DIR__ . '/page_visibility_helper.php';

// Get user role and tenant_id for visibility checks
$userRole = $currentUser['role'] ?? 'user';
$userTenantId = $currentUser['tenant_id'] ?? null;

// Super admin always sees everything
$isSuperAdmin = ($userRole === 'super_admin');

/**
 * Check if a page should be visible in sidebar
 */
function shouldShowPage($pageName, $role, $tenantId, $isSuperAdmin) {
    if ($isSuperAdmin) return true;
    return isPageVisibleForRole($pageName, $role, $tenantId);
}
?>

<div class="sidebar">
    <div class="sidebar-header">
        <div class="sidebar-logo">
            <img src="<?php echo strpos($_SERVER['PHP_SELF'], '/api/') !== false ? '../' : ''; ?>assets/images/logo.png" alt="CollaboraNexio" class="logo-img">
            <span class="logo-text">NEXIO</span>
        </div>
        <div class="sidebar-subtitle">Semplifica, Connetti, Cresci Insieme</div>
    </div>

    <nav class="sidebar-nav">
        <?php
        // AREA OPERATIVA - Check if any items are visible
        $operativeItems = [
            ['dashboard', 'dashboard.php', 'icon--home', 'Dashboard'],
            ['files', 'files.php', 'icon--folder', 'File Manager'],
            ['calendar', 'calendar.php', 'icon--calendar', 'Calendario'],
            ['tasks', 'tasks.php', 'icon--check', 'Task'],
            ['ticket', 'ticket.php', 'icon--ticket', 'Ticket'],
            ['conformita', 'conformita.php', 'icon--shield', 'Conformità'],
            ['ai', 'ai.php', 'icon--cpu', 'AI']
        ];

        $hasOperativeItems = false;
        foreach ($operativeItems as $item) {
            if (shouldShowPage($item[0], $userRole, $userTenantId, $isSuperAdmin)) {
                $hasOperativeItems = true;
                break;
            }
        }

        if ($hasOperativeItems): ?>
        <div class="nav-section">
            <div class="nav-section-title">AREA OPERATIVA</div>
            <?php foreach ($operativeItems as $item):
                if (shouldShowPage($item[0], $userRole, $userTenantId, $isSuperAdmin)): ?>
                <a href="<?php echo $item[1]; ?>" class="nav-item <?php echo $current_page === $item[1] ? 'active' : ''; ?>">
                    <i class="icon <?php echo $item[2]; ?>"></i> <?php echo $item[3]; ?>
                </a>
            <?php endif; endforeach; ?>
        </div>
        <?php endif; ?>

        <?php
        // GESTIONE - Check if visible
        if (shouldShowPage('aziende', $userRole, $userTenantId, $isSuperAdmin)): ?>
        <div class="nav-section">
            <div class="nav-section-title">GESTIONE</div>
            <a href="aziende.php" class="nav-item <?php echo $current_page === 'aziende.php' ? 'active' : ''; ?>">
                <i class="icon icon--building"></i> Aziende
            </a>
        </div>
        <?php endif; ?>

        <?php
        // AMMINISTRAZIONE - Check if any items are visible
        $adminItems = [
            ['utenti', 'utenti.php', 'icon--users', 'Utenti'],
            ['audit_log', 'audit_log.php', 'icon--chart', 'Audit Log'],
            ['configurazioni', 'configurazioni.php', 'icon--settings', 'Configurazioni']
        ];

        $hasAdminItems = false;
        foreach ($adminItems as $item) {
            if (shouldShowPage($item[0], $userRole, $userTenantId, $isSuperAdmin)) {
                $hasAdminItems = true;
                break;
            }
        }

        if ($hasAdminItems): ?>
        <div class="nav-section">
            <div class="nav-section-title">AMMINISTRAZIONE</div>
            <?php foreach ($adminItems as $item):
                if (shouldShowPage($item[0], $userRole, $userTenantId, $isSuperAdmin)): ?>
                <a href="<?php echo $item[1]; ?>" class="nav-item <?php echo $current_page === $item[1] ? 'active' : ''; ?>">
                    <i class="icon <?php echo $item[2]; ?>"></i> <?php echo $item[3]; ?>
                </a>
            <?php endif; endforeach; ?>
        </div>
        <?php endif; ?>

        <div class="nav-section">
            <div class="nav-section-title">ACCOUNT</div>
            <a href="profilo.php" class="nav-item <?php echo $current_page === 'profilo.php' ? 'active' : ''; ?>">
                <i class="icon icon--user"></i> Il Mio Profilo
            </a>
            <a href="logout.php" class="nav-item <?php echo $current_page === 'logout.php' ? 'active' : ''; ?>">
                <i class="icon icon--logout"></i> Esci
            </a>
        </div>
    </nav>

    <div class="sidebar-footer">
        <div class="user-info">
            <div class="user-avatar">
                <?php
                echo isset($currentUser['name']) ? strtoupper(substr($currentUser['name'], 0, 2)) : 'UN';
                ?>
            </div>
            <div class="user-details">
                <div class="user-name">
                    <?php echo htmlspecialchars($currentUser['name'] ?? 'Utente'); ?>
                </div>
                <div class="user-badge">
                    <?php echo strtoupper(str_replace('_', ' ', $currentUser['role'] ?? 'USER')); ?>
                </div>
            </div>
        </div>
    </div>
</div>
