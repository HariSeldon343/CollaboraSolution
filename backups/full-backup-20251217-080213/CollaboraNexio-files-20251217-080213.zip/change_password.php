<?php
/**
 * Change Password Page
 * Used when user password has expired (90-day policy)
 */
session_start();
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/password_expiry_helper.php';

$error = '';
$success = false;
$userId = $_GET['user_id'] ?? $_SESSION['user_id'] ?? null;
$userData = null;
$isExpired = false;
$maxAgeDays = 90;

// Must have user_id
if (!$userId) {
    header('Location: index.php');
    exit;
}

// Get user data
try {
    $db = Database::getInstance();
    $conn = $db->getConnection();

    // Try with password_max_age_days (migration 20); fallback if column doesn't exist yet.
    try {
        $query = "SELECT id, email, name, password_expires_at, password_max_age_days
                  FROM users
                  WHERE id = :user_id
                  AND is_active = 1";

        $stmt = $conn->prepare($query);
        $stmt->bindParam(':user_id', $userId);
        $stmt->execute();

        $userData = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $qe) {
        $query = "SELECT id, email, name, password_expires_at
                  FROM users
                  WHERE id = :user_id
                  AND is_active = 1";

        $stmt = $conn->prepare($query);
        $stmt->bindParam(':user_id', $userId);
        $stmt->execute();

        $userData = $stmt->fetch(PDO::FETCH_ASSOC);
    }

    if (!$userData) {
        $error = 'Utente non trovato';
    } else {
        $expiresAt = $userData['password_expires_at'] ?? null;
        $isExpired = ($expiresAt !== null && $expiresAt !== '' && strtotime((string)$expiresAt) !== false && strtotime((string)$expiresAt) < time());
        $maxAgeDays = isset($userData['password_max_age_days']) ? (int)$userData['password_max_age_days'] : 90;
        if ($maxAgeDays <= 0) {
            $maxAgeDays = 90;
        }
    }
} catch (Exception $e) {
    error_log('Change password error: ' . $e->getMessage());
    $error = 'Si è verificato un errore. Riprova più tardi.';
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $userData) {
    $currentPassword = $_POST['current_password'] ?? '';
    $newPassword = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    $expiryCode = $_POST['expiry_code'] ?? '';

    // Validazione
    $errors = [];

    if (empty($currentPassword)) {
        $errors[] = 'Inserisci la password attuale';
    }

    // When password is expired, require 6-digit code received by email (T-1 notice / resend)
    $verifiedCodeId = null;
    if ($isExpired) {
        // Ensure code table exists; otherwise user cannot complete required flow
        try {
            $tbl = $db->fetchOne(
                "SELECT COUNT(*) AS cnt
                 FROM information_schema.TABLES
                 WHERE TABLE_SCHEMA = DATABASE()
                   AND TABLE_NAME = 'password_expiry_codes'"
            );
            if ((int)($tbl['cnt'] ?? 0) === 0) {
                $errors[] = 'Sistema codici scadenza non configurato. Contatta l’amministratore.';
            }
        } catch (Exception $e) {
            $errors[] = 'Sistema codici scadenza non configurato. Contatta l’amministratore.';
        }

        if (empty($expiryCode)) {
            $errors[] = 'Inserisci il codice a 6 cifre ricevuto via email';
        } else {
            try {
                $verifiedCodeId = cnx_verify_password_expiry_code($db, (int)$userId, (string)$expiryCode);
                if ($verifiedCodeId === null) {
                    $errors[] = 'Codice non valido o scaduto';
                }
            } catch (Exception $e) {
                error_log('Password expiry code verify error: ' . $e->getMessage());
                $errors[] = 'Errore durante la verifica del codice';
            }
        }
    }

    if (strlen($newPassword) < 8) {
        $errors[] = 'La nuova password deve contenere almeno 8 caratteri';
    }
    if (!preg_match('/[A-Z]/', $newPassword)) {
        $errors[] = 'La nuova password deve contenere almeno una lettera maiuscola';
    }
    if (!preg_match('/[a-z]/', $newPassword)) {
        $errors[] = 'La nuova password deve contenere almeno una lettera minuscola';
    }
    if (!preg_match('/[0-9]/', $newPassword)) {
        $errors[] = 'La nuova password deve contenere almeno un numero';
    }
    if ($newPassword !== $confirmPassword) {
        $errors[] = 'Le password non coincidono';
    }

    if (empty($errors)) {
        try {
            // Verify current password
            $verifyQuery = "SELECT password_hash FROM users WHERE id = :user_id";
            $verifyStmt = $conn->prepare($verifyQuery);
            $verifyStmt->bindParam(':user_id', $userId);
            $verifyStmt->execute();
            $currentHash = $verifyStmt->fetchColumn();

            if (!password_verify($currentPassword, $currentHash)) {
                $errors[] = 'Password attuale non corretta';
            } else {
                // Hash new password
                $newPasswordHash = password_hash($newPassword, PASSWORD_DEFAULT);

                // Calculate new expiration (per-user max age; default 90 days)
                $passwordExpiresAt = date('Y-m-d H:i:s', strtotime('+' . $maxAgeDays . ' days'));

                // Build update query based on available columns (avoid breaking older DBs)
                $hasPasswordSetAt = true;
                $hasPasswordExpiresAt = true;
                try {
                    $cols = $db->fetchAll(
                        "SELECT COLUMN_NAME
                         FROM information_schema.COLUMNS
                         WHERE TABLE_SCHEMA = DATABASE()
                           AND TABLE_NAME = 'users'
                           AND COLUMN_NAME IN ('password_set_at', 'password_expires_at')"
                    );
                    $names = array_map(static fn($r) => (string)$r['COLUMN_NAME'], $cols);
                    $hasPasswordSetAt = in_array('password_set_at', $names, true);
                    $hasPasswordExpiresAt = in_array('password_expires_at', $names, true);
                } catch (Exception $e) {
                    // default true
                }

                $setParts = ["password_hash = :password_hash"];
                if ($hasPasswordSetAt) {
                    $setParts[] = "password_set_at = NOW()";
                }
                if ($hasPasswordExpiresAt) {
                    $setParts[] = "password_expires_at = :password_expires_at";
                }

                $updateQuery = "UPDATE users SET " . implode(", ", $setParts) . " WHERE id = :user_id";

                $updateStmt = $conn->prepare($updateQuery);
                $updateStmt->bindParam(':password_hash', $newPasswordHash);
                if (strpos($updateQuery, ':password_expires_at') !== false) {
                    $updateStmt->bindParam(':password_expires_at', $passwordExpiresAt);
                }
                $updateStmt->bindParam(':user_id', $userId);

                if ($updateStmt->execute()) {
                    $success = true;

                    // Mark code as used only after successful password change
                    if ($isExpired && $verifiedCodeId !== null) {
                        try {
                            cnx_mark_password_expiry_code_used($db, (int)$verifiedCodeId);
                        } catch (Exception $e) {
                            error_log('Password expiry code mark used failed: ' . $e->getMessage());
                        }
                    }

                    // Log audit using correct schema (description, not details)
                    try {
                        $desc = 'Password cambiata (policy ' . $maxAgeDays . ' giorni)';
                        if ($isExpired) {
                            $desc = 'Password cambiata (policy ' . $maxAgeDays . ' giorni, cambio forzato con codice)';
                        }

                        $auditQuery = "INSERT INTO audit_logs (
                                        tenant_id, user_id, action, entity_type, entity_id,
                                        description, ip_address, severity, status, created_at
                                      )
                                      SELECT
                                        tenant_id,
                                        :user_id,
                                        'password_change',
                                        'user',
                                        :user_id,
                                        :description,
                                        :ip_address,
                                        'info',
                                        'success',
                                        NOW()
                                      FROM users WHERE id = :user_id";
                        $auditStmt = $conn->prepare($auditQuery);
                        $auditStmt->bindParam(':user_id', $userId);
                        $auditStmt->bindParam(':description', $desc);
                        $auditStmt->bindParam(':ip_address', $_SERVER['REMOTE_ADDR']);
                        $auditStmt->execute();
                    } catch (Exception $auditEx) {
                        // Log error but don't fail the password change
                        error_log("Audit log failed: " . $auditEx->getMessage());
                    }

                    // Set session if not already logged in
                    if (!isset($_SESSION['user_id'])) {
                        $_SESSION['user_id'] = $userData['id'];
                        $_SESSION['user_name'] = $userData['name'];
                        $_SESSION['user_email'] = $userData['email'];
                    }
                } else {
                    $errors[] = 'Errore durante il cambio password. Riprova.';
                }
            }
        } catch (Exception $e) {
            error_log('Password change error: ' . $e->getMessage());
            $errors[] = 'Si è verificato un errore. Riprova più tardi.';
        }
    }

    if (!empty($errors)) {
        $error = implode('<br>', $errors);
    }
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cambio Password - Nexio</title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }

        .password-container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            max-width: 500px;
            width: 100%;
            padding: 40px;
        }

        .header {
            text-align: center;
            margin-bottom: 30px;
        }

        .header h1 {
            color: #2d3748;
            margin-bottom: 10px;
            font-size: 28px;
        }

        .header p {
            color: #718096;
            font-size: 14px;
        }

        .warning-box {
            background: #fff3cd;
            border-left: 4px solid #ffc107;
            padding: 15px;
            margin-bottom: 25px;
            border-radius: 4px;
        }

        .warning-box strong {
            color: #856404;
            display: block;
            margin-bottom: 5px;
        }

        .warning-box p {
            color: #856404;
            margin: 0;
            font-size: 14px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            color: #4a5568;
            font-weight: 500;
            margin-bottom: 8px;
            font-size: 14px;
        }

        input[type="password"] {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.3s ease;
            background: #f7fafc;
        }

        input[type="password"]:focus {
            outline: none;
            border-color: #667eea;
            background: white;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .password-requirements {
            background: #f8f9fa;
            border-radius: 6px;
            padding: 15px;
            margin-bottom: 20px;
            font-size: 13px;
        }

        .password-requirements h4 {
            color: #2d3748;
            margin-bottom: 10px;
            font-size: 14px;
        }

        .password-requirements ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .password-requirements li {
            color: #4a5568;
            padding: 4px 0;
            padding-left: 20px;
            position: relative;
        }

        .password-requirements li:before {
            content: '✓';
            position: absolute;
            left: 0;
            color: #48bb78;
        }

        .btn {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }

        .btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }

        .alert {
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .alert-error {
            background: #fed7d7;
            color: #9b2c2c;
            border-left: 4px solid #f56565;
        }

        .alert-success {
            background: #c6f6d5;
            color: #22543d;
            border-left: 4px solid #48bb78;
        }

        .success-actions {
            text-align: center;
            margin-top: 20px;
        }

        .success-actions a {
            display: inline-block;
            padding: 12px 24px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .success-actions a:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }
    </style>
</head>
<body>
    <div class="password-container">
        <div class="header">
            <h1>Cambio Password Richiesto</h1>
            <?php if ($userData): ?>
                <p>Ciao, <strong><?php echo htmlspecialchars($userData['name']); ?></strong></p>
            <?php endif; ?>
        </div>

        <?php if (!$userData && $error): ?>
            <div class="alert alert-error">
                <?php echo $error; ?>
            </div>
            <div class="success-actions">
                <a href="index.php">Torna al Login</a>
            </div>
        <?php elseif ($success): ?>
            <div class="alert alert-success">
                Password cambiata con successo! La tua nuova password scadrà tra <?php echo (int)$maxAgeDays; ?> giorni.
            </div>
            <div class="success-actions">
                <a href="dashboard.php">Vai alla Dashboard</a>
            </div>
        <?php else: ?>
            <div class="warning-box">
                <?php if ($isExpired): ?>
                    <strong>Password Scaduta</strong>
                    <p>La tua password è scaduta. Per motivi di sicurezza, devi impostare una nuova password e inserire il codice a 6 cifre ricevuto via email.</p>
                <?php else: ?>
                    <strong>Cambio Password</strong>
                    <p>Imposta una nuova password. La policy prevede una scadenza di <?php echo (int)$maxAgeDays; ?> giorni.</p>
                <?php endif; ?>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-error">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <label for="current_password">Password Attuale</label>
                    <input type="password" id="current_password" name="current_password" required autofocus>
                </div>

                <?php if ($isExpired): ?>
                    <div class="form-group">
                        <label for="expiry_code">Codice 6 cifre</label>
                        <input type="text" id="expiry_code" name="expiry_code" inputmode="numeric" pattern="\\d{6}" maxlength="6" placeholder="Es. 123456" required>
                        <div style="margin-top:6px;font-size:12px;line-height:18px;color:#718096;">
                            Inserisci il codice ricevuto via email di avviso scadenza.
                        </div>
                    </div>
                <?php endif; ?>

                <div class="password-requirements">
                    <h4>Requisiti Nuova Password:</h4>
                    <ul>
                        <li>Minimo 8 caratteri</li>
                        <li>Almeno una lettera maiuscola</li>
                        <li>Almeno una lettera minuscola</li>
                        <li>Almeno un numero</li>
                    </ul>
                </div>

                <div class="form-group">
                    <label for="new_password">Nuova Password</label>
                    <input type="password" id="new_password" name="new_password" required>
                </div>

                <div class="form-group">
                    <label for="confirm_password">Conferma Nuova Password</label>
                    <input type="password" id="confirm_password" name="confirm_password" required>
                </div>

                <button type="submit" class="btn">Cambia Password</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
