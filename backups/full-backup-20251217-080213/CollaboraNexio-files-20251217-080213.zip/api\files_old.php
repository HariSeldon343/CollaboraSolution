<?php
/**
 * RESTful File Management API for CollaboraNexio
 *
 * Endpoint: /api/files.php
 *
 * Main Endpoints:
 * - GET    /api/files.php              - List files with filtering and pagination
 * - GET    /api/files.php?id={id}      - Get single file details
 * - POST   /api/files.php              - Upload files (multipart/form-data)
 * - PUT    /api/files.php?id={id}      - Update file metadata
 * - DELETE /api/files.php?id={id}      - Delete file (soft delete by default)
 *
 * Action Endpoints:
 * - GET    ?action=download&id={id}    - Download file
 * - GET    ?action=info&id={id}        - Get detailed file information
 * - GET    ?action=preview&id={id}     - Generate preview/thumbnail
 * - GET    ?action=versions&id={id}    - Get file versions
 * - POST   ?action=restore&id={id}     - Restore from trash
 * - POST   ?action=share               - Create share link
 * - POST   ?action=copy&id={id}        - Copy file
 * - POST   ?action=lock&id={id}        - Lock file for editing
 * - POST   ?action=unlock&id={id}      - Unlock file
 *
 * @version 2.0.0
 * @since PHP 8.0
 */

// PRIMA COSA: Includi session_init.php per configurare sessione correttamente
require_once __DIR__ . '/../includes/session_init.php';


declare(strict_types=1);

// Error reporting configuration
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

// Session configuration with security settings// Required security headers
header('Content-Type: application/json; charset=UTF-8');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');
header('Cache-Control: no-store, no-cache, must-revalidate, private');
header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
header('Referrer-Policy: strict-origin-when-cross-origin');

// CORS headers for cross-origin requests
if (isset($_SERVER['HTTP_ORIGIN'])) {
    header('Access-Control-Allow-Origin: ' . $_SERVER['HTTP_ORIGIN']);
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization, X-CSRF-Token, X-File-Name, X-File-Size');
    header('Access-Control-Max-Age: 86400');
}

// Handle CORS preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Include required files
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';

// File management configuration
define('UPLOAD_MAX_SIZE', 100 * 1024 * 1024); // 100MB
define('CHUNK_SIZE', 2 * 1024 * 1024); // 2MB chunks
define('UPLOAD_RATE_LIMIT', 10); // Files per minute
define('UPLOAD_DIR', '/var/www/files/'); // Base upload directory
define('ALLOWED_MIME_TYPES', [
    'document' => ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
    'spreadsheet' => ['application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
    'image' => ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml'],
    'video' => ['video/mp4', 'video/webm', 'video/ogg'],
    'audio' => ['audio/mpeg', 'audio/wav', 'audio/ogg'],
    'archive' => ['application/zip', 'application/x-tar', 'application/x-7z-compressed'],
    'text' => ['text/plain', 'text/html', 'text/css', 'text/javascript', 'application/json']
]);

// Initialize components
try {
    $auth = new Auth();
    $db = Database::getInstance()->getConnection();
} catch (Exception $e) {
    error_log('File API initialization error: ' . $e->getMessage());
    sendErrorResponse(500, 'Server configuration error');
}

// Authentication check for all requests
if (!$auth->isLoggedIn()) {
    sendErrorResponse(401, 'Authentication required');
}

// Get current user and tenant information
$userId = $_SESSION['user_id'] ?? 0;
$tenantId = $_SESSION['tenant_id'] ?? 0;
$userRole = $_SESSION['role'] ?? '';

// Rate limiting check for uploads
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_GET['action'])) {
    checkRateLimit($userId);
}

// Route request based on method and action
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';
$fileId = isset($_GET['id']) ? (int)$_GET['id'] : null;

try {
    switch ($method) {
        case 'GET':
            if ($fileId && !$action) {
                // Get single file details
                handleGetFile($fileId);
            } elseif ($action) {
                // Handle action-based GET requests
                switch ($action) {
                    case 'download':
                        handleDownloadFile($fileId);
                        break;
                    case 'info':
                        handleGetFileInfo($fileId);
                        break;
                    case 'preview':
                        handleGeneratePreview($fileId);
                        break;
                    case 'versions':
                        handleGetVersions($fileId);
                        break;
                    default:
                        sendErrorResponse(400, "Invalid action: $action");
                }
            } else {
                // List files with filters and pagination
                handleListFiles();
            }
            break;

        case 'POST':
            if ($action) {
                // Handle action-based POST requests
                switch ($action) {
                    case 'restore':
                        handleRestoreFile($fileId);
                        break;
                    case 'share':
                        handleShareFile();
                        break;
                    case 'copy':
                        handleCopyFile($fileId);
                        break;
                    case 'chunk':
                        handleChunkedUpload();
                        break;
                    case 'lock':
                        handleLockFile($fileId);
                        break;
                    case 'unlock':
                        handleUnlockFile($fileId);
                        break;
                    default:
                        sendErrorResponse(400, "Invalid action: $action");
                }
            } else {
                // Handle file upload
                handleUploadFiles();
            }
            break;

        case 'PUT':
            if (!$fileId) {
                sendErrorResponse(400, 'File ID required for update');
            }
            handleUpdateFile($fileId);
            break;

        case 'DELETE':
            if (!$fileId) {
                sendErrorResponse(400, 'File ID required for deletion');
            }
            handleDeleteFile($fileId);
            break;

        default:
            sendErrorResponse(405, "Method not allowed: $method");
    }

} catch (Exception $e) {
    error_log('File API error: ' . $e->getMessage());
    sendErrorResponse(500, 'An error occurred processing your request');
}

/**
 * Handle listing files with filtering and pagination
 */
function handleListFiles(): void {
    global $db, $tenantId, $userId;

    // Extract and validate query parameters
    $folderId = isset($_GET['folder_id']) ? (int)$_GET['folder_id'] : null;
    $page = max(1, (int)($_GET['page'] ?? 1));
    $limit = min(100, max(1, (int)($_GET['limit'] ?? 20)));
    $offset = ($page - 1) * $limit;

    $sort = $_GET['sort'] ?? 'name';
    $order = strtoupper($_GET['order'] ?? 'ASC');
    $search = $_GET['search'] ?? '';
    $type = $_GET['type'] ?? '';
    $dateFrom = $_GET['date_from'] ?? '';
    $dateTo = $_GET['date_to'] ?? '';
    $sizeMin = isset($_GET['size_min']) ? (int)$_GET['size_min'] : null;
    $sizeMax = isset($_GET['size_max']) ? (int)$_GET['size_max'] : null;

    // Validate sort field and order
    $allowedSorts = ['name', 'size', 'date', 'type'];
    $sortMap = [
        'name' => 'original_name',
        'size' => 'size',
        'date' => 'created_at',
        'type' => 'mime_type'
    ];

    if (!isset($sortMap[$sort])) {
        $sort = 'name';
    }
    $sortField = $sortMap[$sort];

    if (!in_array($order, ['ASC', 'DESC'])) {
        $order = 'ASC';
    }

    // Build query with filters
    $query = "SELECT
                f.id,
                f.original_name as name,
                f.size,
                f.mime_type,
                f.folder_id,
                f.created_at,
                f.modified_at,
                f.user_id as created_by,
                f.description,
                f.metadata,
                u.name as creator_name,
                fo.name as folder_name
              FROM files f
              LEFT JOIN users u ON f.user_id = u.id
              LEFT JOIN folders fo ON f.folder_id = fo.id
              WHERE f.tenant_id = :tenant_id AND f.deleted_at IS NULL";

    $params = [':tenant_id' => $tenantId];

    // Apply folder filter
    if ($folderId !== null) {
        $query .= " AND f.folder_id = :folder_id";
        $params[':folder_id'] = $folderId;
    }

    // Apply search filter
    if ($search) {
        $query .= " AND f.original_name LIKE :search";
        $params[':search'] = '%' . $search . '%';
    }

    // Apply type filter
    if ($type && isset(ALLOWED_MIME_TYPES[$type])) {
        $mimeTypes = ALLOWED_MIME_TYPES[$type];
        $placeholders = [];
        foreach ($mimeTypes as $i => $mimeType) {
            $placeholders[] = ":type_$i";
            $params[":type_$i"] = $mimeType;
        }
        $query .= " AND f.mime_type IN (" . implode(',', $placeholders) . ")";
    }

    // Apply date filters
    if ($dateFrom) {
        $query .= " AND f.created_at >= :date_from";
        $params[':date_from'] = $dateFrom;
    }
    if ($dateTo) {
        $query .= " AND f.created_at <= :date_to";
        $params[':date_to'] = $dateTo . ' 23:59:59';
    }

    // Apply size filters
    if ($sizeMin !== null) {
        $query .= " AND f.size >= :size_min";
        $params[':size_min'] = $sizeMin;
    }
    if ($sizeMax !== null) {
        $query .= " AND f.size <= :size_max";
        $params[':size_max'] = $sizeMax;
    }

    // Get total count for pagination
    $countQuery = str_replace(
        'SELECT f.id, f.original_name as name, f.size, f.mime_type, f.folder_id, f.created_at, f.modified_at, f.user_id as created_by, f.description, f.metadata, u.name as creator_name, fo.name as folder_name',
        'SELECT COUNT(*) as total',
        $query
    );

    $stmt = $db->prepare($countQuery);
    $stmt->execute($params);
    $total = (int)$stmt->fetch(PDO::FETCH_ASSOC)['total'];

    // Apply sorting and pagination
    $query .= " ORDER BY f.$sortField $order LIMIT :limit OFFSET :offset";
    $params[':limit'] = $limit;
    $params[':offset'] = $offset;

    // Execute main query
    $stmt = $db->prepare($query);
    foreach ($params as $key => $value) {
        if ($key === ':limit' || $key === ':offset') {
            $stmt->bindValue($key, $value, PDO::PARAM_INT);
        } else {
            $stmt->bindValue($key, $value);
        }
    }
    $stmt->execute();

    $files = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        // Parse metadata if it exists
        if ($row['metadata']) {
            $row['metadata'] = json_decode($row['metadata'], true);
        }

        // Add file URL
        $row['url'] = "/api/files.php?action=download&id=" . $row['id'];
        $row['preview_url'] = "/api/files.php?action=preview&id=" . $row['id'];

        $files[] = $row;
    }

    // Prepare response
    $responseData = [
        'files' => $files,
        'pagination' => [
            'total' => $total,
            'page' => $page,
            'limit' => $limit,
            'pages' => (int)ceil($total / $limit)
        ],
        'filters' => [
            'folder_id' => $folderId,
            'search' => $search,
            'type' => $type,
            'date_from' => $dateFrom,
            'date_to' => $dateTo,
            'size_min' => $sizeMin,
            'size_max' => $sizeMax,
            'sort' => $sort,
            'order' => $order
        ]
    ];

    sendResponse(true, $responseData, 'Files retrieved successfully');
}

/**
 * Handle getting single file details
 */
function handleGetFile(int $fileId): void {
    global $db, $tenantId;

    $query = "SELECT
                f.*,
                u.name as creator_name,
                u.email as creator_email,
                fo.name as folder_name,
                fo.path as folder_path
              FROM files f
              LEFT JOIN users u ON f.user_id = u.id
              LEFT JOIN folders fo ON f.folder_id = fo.id
              WHERE f.id = :file_id AND f.tenant_id = :tenant_id AND f.deleted_at IS NULL";

    $stmt = $db->prepare($query);
    $stmt->execute([':file_id' => $fileId, ':tenant_id' => $tenantId]);
    $file = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$file) {
        sendErrorResponse(404, 'File not found');
    }

    // Parse metadata
    if ($file['metadata']) {
        $file['metadata'] = json_decode($file['metadata'], true);
    }

    // Add URLs
    $file['url'] = "/api/files.php?action=download&id=" . $file['id'];
    $file['preview_url'] = "/api/files.php?action=preview&id=" . $file['id'];

    // Get file permissions for current user
    $file['permissions'] = getFilePermissions($fileId, $tenantId);

    sendResponse(true, $file, 'File details retrieved successfully');
}

/**
 * Handle file upload
 */
function handleUploadFiles(): void {
    global $db, $tenantId, $userId;

    // Validate request
    if (empty($_FILES['files'])) {
        sendErrorResponse(400, 'No files provided');
    }

    // Get additional parameters
    $folderId = isset($_POST['folder_id']) ? (int)$_POST['folder_id'] : null;
    $metadata = isset($_POST['metadata']) ? json_decode($_POST['metadata'], true) : null;

    // Process chunk parameters if present
    $chunkIndex = isset($_POST['chunk_index']) ? (int)$_POST['chunk_index'] : null;
    $chunkTotal = isset($_POST['chunk_total']) ? (int)$_POST['chunk_total'] : null;
    $fileIdentifier = $_POST['file_id'] ?? null;

    $uploaded = [];
    $failed = [];
    $duplicates = [];

    // Process each uploaded file
    $files = reArrayFiles($_FILES['files']);

    foreach ($files as $file) {
        // Basic validation
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $failed[] = [
                'name' => $file['name'],
                'error' => getUploadErrorMessage($file['error'])
            ];
            continue;
        }

        // Size validation
        if ($file['size'] > UPLOAD_MAX_SIZE) {
            $failed[] = [
                'name' => $file['name'],
                'error' => 'File size exceeds maximum allowed size (100MB)'
            ];
            continue;
        }

        // MIME type validation
        $mimeType = mime_content_type($file['tmp_name']);
        if (!isAllowedMimeType($mimeType)) {
            $failed[] = [
                'name' => $file['name'],
                'error' => 'File type not allowed'
            ];
            continue;
        }

        // Check for duplicates
        $hash = hash_file('sha256', $file['tmp_name']);
        if ($existingFile = checkDuplicateFile($hash, $tenantId)) {
            $duplicates[] = [
                'name' => $file['name'],
                'existing_id' => $existingFile['id'],
                'existing_name' => $existingFile['original_name']
            ];
            continue;
        }

        // Generate unique filename and path
        $uniqueName = generateUniqueFileName($file['name']);
        $storagePath = generateStoragePath($tenantId, $uniqueName);

        // Create directory if it doesn't exist
        $directory = dirname($storagePath);
        if (!is_dir($directory)) {
            mkdir($directory, 0755, true);
        }

        // Move uploaded file
        if (!move_uploaded_file($file['tmp_name'], $storagePath)) {
            $failed[] = [
                'name' => $file['name'],
                'error' => 'Failed to save file'
            ];
            continue;
        }

        // Insert file record into database
        $query = "INSERT INTO files (
                    tenant_id, original_name, secure_name, size, mime_type,
                    hash, path, folder_id, user_id, metadata, created_at
                  ) VALUES (
                    :tenant_id, :original_name, :secure_name, :size, :mime_type,
                    :hash, :path, :folder_id, :user_id, :metadata, NOW()
                  )";

        $metadataJson = $metadata ? json_encode($metadata) : null;

        $stmt = $db->prepare($query);
        $result = $stmt->execute([
            ':tenant_id' => $tenantId,
            ':original_name' => $file['name'],
            ':secure_name' => $uniqueName,
            ':size' => $file['size'],
            ':mime_type' => $mimeType,
            ':hash' => $hash,
            ':path' => $storagePath,
            ':folder_id' => $folderId,
            ':user_id' => $userId,
            ':metadata' => $metadataJson
        ]);

        if ($result) {
            $fileId = (int)$db->lastInsertId();
            $uploaded[] = [
                'id' => $fileId,
                'name' => $file['name'],
                'size' => $file['size'],
                'mime_type' => $mimeType,
                'url' => "/api/files.php?action=download&id=$fileId"
            ];

            // Log file activity
            logFileActivity($fileId, 'upload', $userId);
        } else {
            // Remove file from storage if database insert fails
            unlink($storagePath);
            $failed[] = [
                'name' => $file['name'],
                'error' => 'Failed to save file information'
            ];
        }
    }

    // Prepare response
    $response = [
        'uploaded' => $uploaded,
        'failed' => $failed,
        'duplicates' => $duplicates
    ];

    $message = sprintf(
        '%d files uploaded successfully',
        count($uploaded)
    );

    $httpCode = count($uploaded) > 0 ? 201 : (count($failed) > 0 ? 400 : 200);
    sendResponse(count($failed) === 0, $response, $message, $httpCode);
}

/**
 * Handle file update
 */
function handleUpdateFile(int $fileId): void {
    global $db, $tenantId, $userId;

    // Check file exists and user has access
    if (!validateFileAccess($fileId, $tenantId, 'write')) {
        sendErrorResponse(404, 'File not found or access denied');
    }

    // Get request body
    $input = json_decode(file_get_contents('php://input'), true);

    if (empty($input)) {
        sendErrorResponse(400, 'Invalid request body');
    }

    // Prepare update fields
    $updates = [];
    $params = [':file_id' => $fileId, ':tenant_id' => $tenantId];

    // Handle name update
    if (isset($input['name'])) {
        $name = trim($input['name']);
        if (empty($name)) {
            sendErrorResponse(400, 'File name cannot be empty');
        }
        $updates[] = 'original_name = :name';
        $params[':name'] = $name;
    }

    // Handle metadata update
    if (isset($input['metadata'])) {
        $updates[] = 'metadata = :metadata';
        $params[':metadata'] = json_encode($input['metadata']);
    }

    // Handle folder move
    if (isset($input['folder_id'])) {
        $folderId = $input['folder_id'] === null ? null : (int)$input['folder_id'];
        $updates[] = 'folder_id = :folder_id';
        $params[':folder_id'] = $folderId;
    }

    if (empty($updates)) {
        sendErrorResponse(400, 'No valid update fields provided');
    }

    // Add modified timestamp
    $updates[] = 'modified_at = NOW()';

    // Execute update
    $query = "UPDATE files SET " . implode(', ', $updates) .
             " WHERE id = :file_id AND tenant_id = :tenant_id";

    $stmt = $db->prepare($query);
    $result = $stmt->execute($params);

    if (!$result) {
        sendErrorResponse(500, 'Failed to update file');
    }

    if ($stmt->rowCount() === 0) {
        sendErrorResponse(404, 'File not found or no changes made');
    }

    // Log activity
    logFileActivity($fileId, 'update', $userId);

    // Fetch and return updated file
    handleGetFile($fileId);
}

/**
 * Handle file deletion
 */
function handleDeleteFile(int $fileId): void {
    global $db, $tenantId, $userId, $userRole;

    // Check file exists and user has access
    if (!validateFileAccess($fileId, $tenantId, 'delete')) {
        sendErrorResponse(404, 'File not found or access denied');
    }

    // Check if permanent delete is requested (admin only)
    $permanent = isset($_GET['permanent']) && $_GET['permanent'] === 'true';

    if ($permanent && $userRole !== 'admin') {
        sendErrorResponse(403, 'Only administrators can permanently delete files');
    }

    if ($permanent) {
        // Get file info for physical deletion
        $query = "SELECT path FROM files WHERE id = :file_id AND tenant_id = :tenant_id";
        $stmt = $db->prepare($query);
        $stmt->execute([':file_id' => $fileId, ':tenant_id' => $tenantId]);
        $file = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($file) {
            // Delete physical file
            if (file_exists($file['path'])) {
                unlink($file['path']);
            }

            // Delete database record
            $deleteQuery = "DELETE FROM files WHERE id = :file_id AND tenant_id = :tenant_id";
            $deleteStmt = $db->prepare($deleteQuery);
            $deleteStmt->execute([':file_id' => $fileId, ':tenant_id' => $tenantId]);

            $message = 'File permanently deleted';
        } else {
            sendErrorResponse(404, 'File not found');
        }
    } else {
        // Soft delete
        $query = "UPDATE files SET
                    deleted_at = NOW(),
                    deleted_by = :user_id
                  WHERE id = :file_id AND tenant_id = :tenant_id";

        $stmt = $db->prepare($query);
        $result = $stmt->execute([
            ':user_id' => $userId,
            ':file_id' => $fileId,
            ':tenant_id' => $tenantId
        ]);

        if (!$result || $stmt->rowCount() === 0) {
            sendErrorResponse(404, 'File not found');
        }

        $message = 'File moved to trash';
    }

    // Log activity
    logFileActivity($fileId, $permanent ? 'permanent_delete' : 'delete', $userId);

    sendResponse(true, null, $message);
}

/**
 * Handle file download
 */
function handleDownloadFile(?int $fileId): void {
    global $db, $tenantId;

    if (!$fileId) {
        sendErrorResponse(400, 'File ID required');
    }

    // Check file exists and user has access
    if (!validateFileAccess($fileId, $tenantId, 'read')) {
        sendErrorResponse(404, 'File not found or access denied');
    }

    // Get file information
    $query = "SELECT original_name, size, mime_type, path
              FROM files
              WHERE id = :file_id AND tenant_id = :tenant_id AND deleted_at IS NULL";

    $stmt = $db->prepare($query);
    $stmt->execute([':file_id' => $fileId, ':tenant_id' => $tenantId]);
    $file = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$file) {
        sendErrorResponse(404, 'File not found');
    }

    // Check if file exists on disk
    if (!file_exists($file['path'])) {
        sendErrorResponse(500, 'File not found in storage');
    }

    // Determine disposition
    $disposition = $_GET['disposition'] ?? 'attachment';
    if (!in_array($disposition, ['inline', 'attachment'])) {
        $disposition = 'attachment';
    }

    // Get version if specified
    $version = isset($_GET['version']) ? (int)$_GET['version'] : null;

    // Log download activity
    logFileActivity($fileId, 'download', $_SESSION['user_id'] ?? 0);

    // Send file headers
    header('Content-Type: ' . $file['mime_type']);
    header('Content-Length: ' . $file['size']);
    header('Content-Disposition: ' . $disposition . '; filename="' . $file['original_name'] . '"');
    header('Cache-Control: private, max-age=0');
    header('Pragma: public');
    header('Expires: 0');

    // Output file
    readfile($file['path']);
    exit();
}

/**
 * Handle file restoration from trash
 */
function handleRestoreFile(?int $fileId): void {
    global $db, $tenantId, $userId;

    if (!$fileId) {
        sendErrorResponse(400, 'File ID required');
    }

    // Check if file exists and is deleted
    $query = "SELECT id, original_name FROM files
              WHERE id = :file_id AND tenant_id = :tenant_id AND deleted_at IS NOT NULL";

    $stmt = $db->prepare($query);
    $stmt->execute([':file_id' => $fileId, ':tenant_id' => $tenantId]);
    $file = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$file) {
        sendErrorResponse(404, 'File not found in trash');
    }

    // Restore file
    $updateQuery = "UPDATE files SET
                      deleted_at = NULL,
                      deleted_by = NULL,
                      modified_at = NOW()
                    WHERE id = :file_id AND tenant_id = :tenant_id";

    $stmt = $db->prepare($updateQuery);
    $result = $stmt->execute([':file_id' => $fileId, ':tenant_id' => $tenantId]);

    if (!$result) {
        sendErrorResponse(500, 'Failed to restore file');
    }

    // Log activity
    logFileActivity($fileId, 'restore', $userId);

    sendResponse(true, ['id' => $fileId, 'name' => $file['original_name']], 'File restored successfully');
}

/**
 * Handle file sharing
 */
function handleShareFile(): void {
    global $db, $tenantId, $userId;

    // Get request body
    $input = json_decode(file_get_contents('php://input'), true);

    if (!isset($input['file_id'])) {
        sendErrorResponse(400, 'File ID required');
    }

    $fileId = (int)$input['file_id'];
    $password = $input['password'] ?? null;
    $expiresAt = $input['expires_at'] ?? null;
    $maxDownloads = isset($input['max_downloads']) ? (int)$input['max_downloads'] : null;

    // Validate file access
    if (!validateFileAccess($fileId, $tenantId, 'share')) {
        sendErrorResponse(404, 'File not found or access denied');
    }

    // Generate unique share token
    $shareToken = bin2hex(random_bytes(32));

    // Hash password if provided
    $hashedPassword = $password ? password_hash($password, PASSWORD_DEFAULT) : null;

    // Validate expiration date
    if ($expiresAt) {
        $expiresAt = date('Y-m-d H:i:s', strtotime($expiresAt));
        if ($expiresAt < date('Y-m-d H:i:s')) {
            sendErrorResponse(400, 'Expiration date must be in the future');
        }
    }

    // Insert share record
    $query = "INSERT INTO file_shares (
                file_id, tenant_id, share_token, password_hash, expires_at,
                max_downloads, created_by, created_at
              ) VALUES (
                :file_id, :tenant_id, :share_token, :password_hash, :expires_at,
                :max_downloads, :created_by, NOW()
              )";

    $stmt = $db->prepare($query);
    $result = $stmt->execute([
        ':file_id' => $fileId,
        ':tenant_id' => $tenantId,
        ':share_token' => $shareToken,
        ':password_hash' => $hashedPassword,
        ':expires_at' => $expiresAt,
        ':max_downloads' => $maxDownloads,
        ':created_by' => $userId
    ]);

    if (!$result) {
        sendErrorResponse(500, 'Failed to create share link');
    }

    $shareId = (int)$db->lastInsertId();

    // Generate share URL
    $shareUrl = sprintf(
        '%s://%s/share/%s',
        isset($_SERVER['HTTPS']) ? 'https' : 'http',
        $_SERVER['HTTP_HOST'],
        $shareToken
    );

    // Log activity
    logFileActivity($fileId, 'share', $userId);

    $response = [
        'share_id' => $shareId,
        'share_url' => $shareUrl,
        'share_token' => $shareToken,
        'expires_at' => $expiresAt,
        'password_protected' => $password !== null,
        'max_downloads' => $maxDownloads
    ];

    sendResponse(true, $response, 'Share link created successfully', 201);
}

/**
 * Handle file copying
 */
function handleCopyFile(?int $fileId): void {
    global $db, $tenantId, $userId;

    if (!$fileId) {
        sendErrorResponse(400, 'File ID required');
    }

    // Get request body
    $input = json_decode(file_get_contents('php://input'), true);
    $targetFolderId = isset($input['folder_id']) ? (int)$input['folder_id'] : null;
    $newName = $input['name'] ?? null;

    // Validate source file access
    if (!validateFileAccess($fileId, $tenantId, 'read')) {
        sendErrorResponse(404, 'File not found or access denied');
    }

    // Get source file information
    $query = "SELECT * FROM files WHERE id = :file_id AND tenant_id = :tenant_id";
    $stmt = $db->prepare($query);
    $stmt->execute([':file_id' => $fileId, ':tenant_id' => $tenantId]);
    $sourceFile = $stmt->fetch(PDO::FETCH_ASSOC);

    // Generate new name if not provided
    if (!$newName) {
        $newName = 'Copy of ' . $sourceFile['original_name'];
    }

    // Copy physical file
    $newUniqueName = generateUniqueFileName($newName);
    $newStoragePath = generateStoragePath($tenantId, $newUniqueName);
    $directory = dirname($newStoragePath);
    if (!is_dir($directory)) {
        mkdir($directory, 0755, true);
    }

    if (!copy($sourceFile['path'], $newStoragePath)) {
        sendErrorResponse(500, 'Failed to copy file');
    }

    // Insert new file record
    $insertQuery = "INSERT INTO files (
                      tenant_id, original_name, secure_name, size, mime_type, hash,
                      path, folder_id, user_id, metadata, copied_from, created_at
                    ) VALUES (
                      :tenant_id, :original_name, :secure_name, :size, :mime_type, :hash,
                      :path, :folder_id, :user_id, :metadata, :copied_from, NOW()
                    )";

    $stmt = $db->prepare($insertQuery);
    $result = $stmt->execute([
        ':tenant_id' => $tenantId,
        ':original_name' => $newName,
        ':secure_name' => $newUniqueName,
        ':size' => $sourceFile['size'],
        ':mime_type' => $sourceFile['mime_type'],
        ':hash' => $sourceFile['hash'],
        ':path' => $newStoragePath,
        ':folder_id' => $targetFolderId ?? $sourceFile['folder_id'],
        ':user_id' => $userId,
        ':metadata' => $sourceFile['metadata'],
        ':copied_from' => $fileId
    ]);

    if (!$result) {
        // Clean up copied file on failure
        unlink($newStoragePath);
        sendErrorResponse(500, 'Failed to create file copy record');
    }

    $newFileId = (int)$db->lastInsertId();

    // Log activity
    logFileActivity($fileId, 'copy', $userId);
    logFileActivity($newFileId, 'created_from_copy', $userId);

    $response = [
        'id' => $newFileId,
        'name' => $newName,
        'folder_id' => $targetFolderId ?? $sourceFile['folder_id'],
        'url' => "/api/files.php?action=download&id=$newFileId",
        'copied_from' => $fileId
    ];

    sendResponse(true, $response, 'File copied successfully', 201);
}

/**
 * Handle detailed file information
 */
function handleGetFileInfo(?int $fileId): void {
    global $db, $tenantId;

    if (!$fileId) {
        sendErrorResponse(400, 'File ID required');
    }

    // Check file access
    if (!validateFileAccess($fileId, $tenantId, 'read')) {
        sendErrorResponse(404, 'File not found or access denied');
    }

    // Get comprehensive file information
    $query = "SELECT
                f.*,
                u.name as creator_name,
                u.email as creator_email,
                fo.name as folder_name,
                fo.path as folder_path,
                (SELECT COUNT(*) FROM file_versions WHERE file_id = f.id) as version_count,
                (SELECT COUNT(*) FROM file_shares WHERE file_id = f.id) as share_count,
                (SELECT COUNT(*) FROM file_activities WHERE file_id = f.id) as activity_count
              FROM files f
              LEFT JOIN users u ON f.user_id = u.id
              LEFT JOIN folders fo ON f.folder_id = fo.id
              WHERE f.id = :file_id AND f.tenant_id = :tenant_id";

    $stmt = $db->prepare($query);
    $stmt->execute([':file_id' => $fileId, ':tenant_id' => $tenantId]);
    $file = $stmt->fetch(PDO::FETCH_ASSOC);

    // Parse metadata
    if ($file['metadata']) {
        $file['metadata'] = json_decode($file['metadata'], true);
    }

    // Get recent activities
    $activityQuery = "SELECT
                        fa.action,
                        fa.details,
                        fa.created_at,
                        u.name as user_name
                      FROM file_activities fa
                      LEFT JOIN users u ON fa.user_id = u.id
                      WHERE fa.file_id = :file_id
                      ORDER BY fa.created_at DESC
                      LIMIT 10";

    $stmt = $db->prepare($activityQuery);
    $stmt->execute([':file_id' => $fileId]);
    $activities = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get active shares
    $shareQuery = "SELECT
                     share_token,
                     expires_at,
                     max_downloads,
                     download_count,
                     created_at
                   FROM file_shares
                   WHERE file_id = :file_id AND (expires_at IS NULL OR expires_at > NOW())
                   ORDER BY created_at DESC";

    $stmt = $db->prepare($shareQuery);
    $stmt->execute([':file_id' => $fileId]);
    $shares = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get file lock status
    $lockQuery = "SELECT
                    fl.locked_at,
                    fl.expires_at,
                    u.name as locked_by_name
                  FROM file_locks fl
                  LEFT JOIN users u ON fl.user_id = u.id
                  WHERE fl.file_id = :file_id AND fl.expires_at > NOW()";

    $stmt = $db->prepare($lockQuery);
    $stmt->execute([':file_id' => $fileId]);
    $lock = $stmt->fetch(PDO::FETCH_ASSOC);

    // Get permissions
    $permissions = getFilePermissions($fileId, $tenantId);

    // Get versions if they exist
    $versionQuery = "SELECT
                       version,
                       size,
                       hash,
                       created_at,
                       comment
                     FROM file_versions
                     WHERE file_id = :file_id
                     ORDER BY version DESC";

    $stmt = $db->prepare($versionQuery);
    $stmt->execute([':file_id' => $fileId]);
    $versions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Compile detailed information
    $response = [
        'file' => $file,
        'permissions' => $permissions,
        'activities' => $activities,
        'shares' => $shares,
        'lock' => $lock,
        'versions' => $versions,
        'urls' => [
            'download' => "/api/files.php?action=download&id=$fileId",
            'preview' => "/api/files.php?action=preview&id=$fileId",
            'versions' => "/api/files.php?action=versions&id=$fileId"
        ]
    ];

    sendResponse(true, $response, 'File information retrieved successfully');
}

/**
 * Handle file preview generation
 */
function handleGeneratePreview(?int $fileId): void {
    global $db, $tenantId;

    if (!$fileId) {
        sendErrorResponse(400, 'File ID required');
    }

    // Check file access
    if (!validateFileAccess($fileId, $tenantId, 'read')) {
        sendErrorResponse(404, 'File not found or access denied');
    }

    // Get file information
    $query = "SELECT original_name, mime_type, path FROM files
              WHERE id = :file_id AND tenant_id = :tenant_id AND deleted_at IS NULL";

    $stmt = $db->prepare($query);
    $stmt->execute([':file_id' => $fileId, ':tenant_id' => $tenantId]);
    $file = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$file) {
        sendErrorResponse(404, 'File not found');
    }

    // Check if preview is supported for this file type
    $supportedTypes = [
        'image/jpeg', 'image/png', 'image/gif', 'image/webp',
        'application/pdf', 'text/plain', 'text/html', 'text/css',
        'text/javascript', 'application/json'
    ];

    if (!in_array($file['mime_type'], $supportedTypes)) {
        sendErrorResponse(415, 'Preview not supported for this file type');
    }

    // Generate preview based on file type
    if (strpos($file['mime_type'], 'image/') === 0) {
        // For images, return the file directly with proper headers
        header('Content-Type: ' . $file['mime_type']);
        header('Cache-Control: public, max-age=86400');
        readfile($file['path']);
        exit();
    } elseif ($file['mime_type'] === 'application/pdf') {
        // Generate PDF preview placeholder
        sendResponse(true, [
            'preview_type' => 'pdf',
            'message' => 'PDF preview generation requires additional libraries',
            'file_name' => $file['original_name']
        ], 'Preview placeholder generated');
    } else {
        // Generate text preview
        $content = file_get_contents($file['path'], false, null, 0, 5000); // First 5KB
        sendResponse(true, [
            'preview_type' => 'text',
            'content' => $content,
            'truncated' => filesize($file['path']) > 5000
        ], 'Text preview generated');
    }
}

/**
 * Handle getting file versions
 */
function handleGetVersions(?int $fileId): void {
    global $db, $tenantId;

    if (!$fileId) {
        sendErrorResponse(400, 'File ID required');
    }

    // Check file access
    if (!validateFileAccess($fileId, $tenantId, 'read')) {
        sendErrorResponse(404, 'File not found or access denied');
    }

    // Get file versions
    $query = "SELECT
                fv.version,
                fv.size,
                fv.hash,
                fv.created_at,
                fv.comment,
                u.name as created_by_name
              FROM file_versions fv
              LEFT JOIN users u ON fv.created_by = u.id
              WHERE fv.file_id = :file_id
              ORDER BY fv.version DESC";

    $stmt = $db->prepare($query);
    $stmt->execute([':file_id' => $fileId]);
    $versions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    sendResponse(true, $versions, 'File versions retrieved successfully');
}

/**
 * Handle file locking
 */
function handleLockFile(?int $fileId): void {
    global $db, $tenantId, $userId;

    if (!$fileId) {
        sendErrorResponse(400, 'File ID required');
    }

    // Check file access
    if (!validateFileAccess($fileId, $tenantId, 'write')) {
        sendErrorResponse(404, 'File not found or access denied');
    }

    // Check if file is already locked
    $checkQuery = "SELECT user_id FROM file_locks
                   WHERE file_id = :file_id AND expires_at > NOW()";

    $stmt = $db->prepare($checkQuery);
    $stmt->execute([':file_id' => $fileId]);
    $lock = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($lock && $lock['user_id'] != $userId) {
        sendErrorResponse(423, 'File is locked by another user');
    }

    // Create or update lock
    $lockDuration = 3600; // 1 hour
    $expiresAt = date('Y-m-d H:i:s', time() + $lockDuration);

    $query = "INSERT INTO file_locks (file_id, user_id, locked_at, expires_at)
              VALUES (:file_id, :user_id, NOW(), :expires_at)
              ON DUPLICATE KEY UPDATE
              locked_at = NOW(), expires_at = :expires_at2";

    $stmt = $db->prepare($query);
    $result = $stmt->execute([
        ':file_id' => $fileId,
        ':user_id' => $userId,
        ':expires_at' => $expiresAt,
        ':expires_at2' => $expiresAt
    ]);

    if (!$result) {
        sendErrorResponse(500, 'Failed to lock file');
    }

    logFileActivity($fileId, 'lock', $userId);

    sendResponse(true, [
        'locked' => true,
        'expires_at' => $expiresAt
    ], 'File locked successfully');
}

/**
 * Handle file unlocking
 */
function handleUnlockFile(?int $fileId): void {
    global $db, $tenantId, $userId, $userRole;

    if (!$fileId) {
        sendErrorResponse(400, 'File ID required');
    }

    // Check if user can unlock (owner or admin)
    $query = "SELECT user_id FROM file_locks
              WHERE file_id = :file_id AND expires_at > NOW()";

    $stmt = $db->prepare($query);
    $stmt->execute([':file_id' => $fileId]);
    $lock = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$lock) {
        sendErrorResponse(400, 'File is not locked');
    }

    if ($lock['user_id'] != $userId && $userRole !== 'admin') {
        sendErrorResponse(403, 'Only the lock owner or admin can unlock this file');
    }

    // Remove lock
    $deleteQuery = "DELETE FROM file_locks WHERE file_id = :file_id";
    $stmt = $db->prepare($deleteQuery);
    $result = $stmt->execute([':file_id' => $fileId]);

    if (!$result) {
        sendErrorResponse(500, 'Failed to unlock file');
    }

    logFileActivity($fileId, 'unlock', $userId);

    sendResponse(true, null, 'File unlocked successfully');
}

/**
 * Handle chunked upload
 */
function handleChunkedUpload(): void {
    global $db, $tenantId, $userId;

    // Get chunk parameters
    $input = json_decode(file_get_contents('php://input'), true);

    $chunkIndex = $input['chunk_index'] ?? null;
    $chunkTotal = $input['chunk_total'] ?? null;
    $fileId = $input['file_id'] ?? null;
    $fileName = $input['file_name'] ?? null;
    $chunkData = $input['chunk_data'] ?? null; // Base64 encoded

    if ($chunkIndex === null || $chunkTotal === null || !$chunkData) {
        sendErrorResponse(400, 'Missing required chunk parameters');
    }

    // Decode chunk data
    $chunkContent = base64_decode($chunkData);
    if ($chunkContent === false) {
        sendErrorResponse(400, 'Invalid chunk data');
    }

    // Create temporary directory for chunks
    $tempDir = sys_get_temp_dir() . '/uploads/' . $tenantId . '/' . $fileId;
    if (!is_dir($tempDir)) {
        mkdir($tempDir, 0755, true);
    }

    // Save chunk
    $chunkPath = $tempDir . '/chunk_' . $chunkIndex;
    file_put_contents($chunkPath, $chunkContent);

    // Check if all chunks are received
    $receivedChunks = count(glob($tempDir . '/chunk_*'));

    if ($receivedChunks === $chunkTotal) {
        // Assemble file from chunks
        $finalPath = generateStoragePath($tenantId, generateUniqueFileName($fileName));
        $directory = dirname($finalPath);
        if (!is_dir($directory)) {
            mkdir($directory, 0755, true);
        }

        $finalFile = fopen($finalPath, 'wb');
        for ($i = 0; $i < $chunkTotal; $i++) {
            $chunkPath = $tempDir . '/chunk_' . $i;
            $chunkContent = file_get_contents($chunkPath);
            fwrite($finalFile, $chunkContent);
            unlink($chunkPath); // Remove chunk after writing
        }
        fclose($finalFile);

        // Remove temporary directory
        rmdir($tempDir);

        // Create file record in database
        $hash = hash_file('sha256', $finalPath);
        $size = filesize($finalPath);
        $mimeType = mime_content_type($finalPath);

        $query = "INSERT INTO files (
                    tenant_id, original_name, secure_name, size, mime_type,
                    hash, path, user_id, created_at
                  ) VALUES (
                    :tenant_id, :original_name, :secure_name, :size, :mime_type,
                    :hash, :path, :user_id, NOW()
                  )";

        $stmt = $db->prepare($query);
        $result = $stmt->execute([
            ':tenant_id' => $tenantId,
            ':original_name' => $fileName,
            ':secure_name' => basename($finalPath),
            ':size' => $size,
            ':mime_type' => $mimeType,
            ':hash' => $hash,
            ':path' => $finalPath,
            ':user_id' => $userId
        ]);

        if ($result) {
            $newFileId = (int)$db->lastInsertId();
            sendResponse(true, [
                'file_id' => $newFileId,
                'completed' => true,
                'url' => "/api/files.php?action=download&id=$newFileId"
            ], 'File upload completed');
        } else {
            unlink($finalPath);
            sendErrorResponse(500, 'Failed to save file record');
        }
    } else {
        // More chunks needed
        sendResponse(true, [
            'chunk_index' => $chunkIndex,
            'chunks_received' => $receivedChunks,
            'chunks_total' => $chunkTotal,
            'completed' => false
        ], 'Chunk received successfully');
    }
}

// Helper functions

/**
 * Send standardized JSON response
 */
function sendResponse(bool $success, $data, string $message, int $httpCode = 200, array $metadata = []): void {
    http_response_code($httpCode);

    $response = [
        'success' => $success,
        'data' => $data,
        'message' => $message,
        'metadata' => array_merge([
            'timestamp' => date('c')
        ], $metadata)
    ];

    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    exit();
}

/**
 * Send error response
 */
function sendErrorResponse(int $httpCode, string $message): void {
    sendResponse(false, null, $message, $httpCode);
}

/**
 * Validate file access permissions
 */
function validateFileAccess(int $fileId, int $tenantId, string $permission): bool {
    global $db, $userId, $userRole;

    // Admins have full access
    if ($userRole === 'admin' || $userRole === 'super_admin') {
        return true;
    }

    // Check if file exists and belongs to tenant
    $query = "SELECT user_id, folder_id FROM files
              WHERE id = :file_id AND tenant_id = :tenant_id AND deleted_at IS NULL";

    $stmt = $db->prepare($query);
    $stmt->execute([':file_id' => $fileId, ':tenant_id' => $tenantId]);
    $file = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$file) {
        return false;
    }

    // Check ownership
    if ($file['user_id'] == $userId) {
        return true;
    }

    // Check explicit file permissions
    $permQuery = "SELECT can_read, can_write, can_delete, can_share
                  FROM file_permissions
                  WHERE file_id = :file_id AND user_id = :user_id";

    $stmt = $db->prepare($permQuery);
    $stmt->execute([':file_id' => $fileId, ':user_id' => $userId]);
    $perms = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($perms) {
        switch ($permission) {
            case 'read':
                return $perms['can_read'] == 1;
            case 'write':
                return $perms['can_write'] == 1;
            case 'delete':
                return $perms['can_delete'] == 1;
            case 'share':
                return $perms['can_share'] == 1;
            default:
                return false;
        }
    }

    return false;
}

/**
 * Get file permissions for current user
 */
function getFilePermissions(int $fileId, int $tenantId): array {
    global $userId, $userRole;

    $permissions = [
        'can_read' => false,
        'can_write' => false,
        'can_delete' => false,
        'can_share' => false,
        'can_download' => false
    ];

    // Check each permission
    $permissions['can_read'] = validateFileAccess($fileId, $tenantId, 'read');
    $permissions['can_write'] = validateFileAccess($fileId, $tenantId, 'write');
    $permissions['can_delete'] = validateFileAccess($fileId, $tenantId, 'delete');
    $permissions['can_share'] = validateFileAccess($fileId, $tenantId, 'share');
    $permissions['can_download'] = $permissions['can_read'];

    return $permissions;
}

/**
 * Check for duplicate files by hash
 */
function checkDuplicateFile(string $hash, int $tenantId): ?array {
    global $db;

    $query = "SELECT id, original_name FROM files
              WHERE hash = :hash AND tenant_id = :tenant_id AND deleted_at IS NULL
              LIMIT 1";

    $stmt = $db->prepare($query);
    $stmt->execute([':hash' => $hash, ':tenant_id' => $tenantId]);

    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result ?: null;
}

/**
 * Generate unique file name
 */
function generateUniqueFileName(string $originalName): string {
    $extension = pathinfo($originalName, PATHINFO_EXTENSION);
    $timestamp = time();
    $random = bin2hex(random_bytes(8));

    return "{$timestamp}_{$random}.{$extension}";
}

/**
 * Generate storage path for file
 */
function generateStoragePath(int $tenantId, string $fileName): string {
    $year = date('Y');
    $month = date('m');
    $day = date('d');

    return UPLOAD_DIR . "tenant_{$tenantId}/{$year}/{$month}/{$day}/{$fileName}";
}

/**
 * Check if MIME type is allowed
 */
function isAllowedMimeType(string $mimeType): bool {
    foreach (ALLOWED_MIME_TYPES as $category => $types) {
        if (in_array($mimeType, $types)) {
            return true;
        }
    }
    return false;
}

/**
 * Re-array uploaded files for easier processing
 */
function reArrayFiles(array $filePost): array {
    $fileArray = [];

    if (isset($filePost['name'])) {
        if (is_array($filePost['name'])) {
            $fileCount = count($filePost['name']);
            $fileKeys = array_keys($filePost);

            for ($i = 0; $i < $fileCount; $i++) {
                foreach ($fileKeys as $key) {
                    $fileArray[$i][$key] = $filePost[$key][$i];
                }
            }
        } else {
            $fileArray[] = $filePost;
        }
    }

    return $fileArray;
}

/**
 * Get upload error message
 */
function getUploadErrorMessage(int $errorCode): string {
    $errors = [
        UPLOAD_ERR_INI_SIZE => 'File exceeds upload_max_filesize directive',
        UPLOAD_ERR_FORM_SIZE => 'File exceeds MAX_FILE_SIZE directive',
        UPLOAD_ERR_PARTIAL => 'File was only partially uploaded',
        UPLOAD_ERR_NO_FILE => 'No file was uploaded',
        UPLOAD_ERR_NO_TMP_DIR => 'Missing temporary folder',
        UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk',
        UPLOAD_ERR_EXTENSION => 'Upload stopped by extension'
    ];

    return $errors[$errorCode] ?? 'Unknown upload error';
}

/**
 * Log file activity
 */
function logFileActivity(int $fileId, string $action, int $userId, ?string $details = null): void {
    global $db;

    $query = "INSERT INTO file_activities (file_id, user_id, action, details, created_at)
              VALUES (:file_id, :user_id, :action, :details, NOW())";

    try {
        $stmt = $db->prepare($query);
        $stmt->execute([
            ':file_id' => $fileId,
            ':user_id' => $userId,
            ':action' => $action,
            ':details' => $details ? json_encode($details) : null
        ]);
    } catch (Exception $e) {
        error_log('Failed to log file activity: ' . $e->getMessage());
    }
}

/**
 * Check rate limit for uploads
 */
function checkRateLimit(int $userId): void {
    global $db;

    // Check uploads in the last minute
    $query = "SELECT COUNT(*) as count
              FROM file_activities
              WHERE user_id = :user_id
                AND action = 'upload'
                AND created_at > DATE_SUB(NOW(), INTERVAL 1 MINUTE)";

    $stmt = $db->prepare($query);
    $stmt->execute([':user_id' => $userId]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result['count'] >= UPLOAD_RATE_LIMIT) {
        sendErrorResponse(429, 'Upload rate limit exceeded. Please wait before uploading more files.');
    }
}

?>