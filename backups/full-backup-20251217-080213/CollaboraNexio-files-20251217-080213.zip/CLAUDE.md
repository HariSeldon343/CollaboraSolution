# CLAUDE.md

This file provides guidance to Claude Code when working with CollaboraNexio.

## Project Overview

**CollaboraNexio** is a multi-tenant enterprise collaboration platform built with vanilla PHP 8.3 (no frameworks) for Italian businesses. Features: document management, task tracking, audit logging, calendar system, and real-time collaboration with OnlyOffice integration.

**Environments:**
- **Development:** http://localhost:8888/CollaboraNexio (XAMPP/Windows)
- **Production:** https://app.nexiosolution.it/CollaboraNexio (Cloudflare)

## Development Setup

### Prerequisites
- PHP 8.3+ (XAMPP recommended)
- MySQL/MariaDB 10.4+
- OnlyOffice Document Server (Docker)

### Configuration
- `config.php` - Development (port 8888)
- `config.production.php` - Production
- Auto-detection via hostname

### Database Management
```bash
cd database/migrations/
mysql -u root collaboranexio < migration_file.sql
```

### Testing
- System Health: http://localhost:8888/CollaboraNexio/system_check.php
- Demo Credentials: `superadmin@collaboranexio.com` / `Admin123!`

## Architecture

### Multi-Tenant Design (MANDATORY)

Every query MUST include BOTH tenant_id AND soft delete:
```php
// ✅ CORRECT
WHERE tenant_id = ? AND deleted_at IS NULL

// ❌ WRONG
WHERE status = 'active'
```

**Exception:** `super_admin` role bypasses tenant isolation.

### Database Pattern

All tenant-scoped tables:
```sql
tenant_id INT NOT NULL,               -- FK with ON DELETE CASCADE
deleted_at TIMESTAMP NULL,            -- Soft delete marker
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
INDEX idx_tenant_created (tenant_id, created_at),
INDEX idx_tenant_deleted (tenant_id, deleted_at)
```

### Authentication Flow

**Page Authentication:**
```php
<?php
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
require_once __DIR__ . '/includes/session_init.php';
require_once __DIR__ . '/includes/auth_simple.php';

$auth = new AuthSimple();
if (!$auth->checkAuth()) {
    header('Location: index.php');
    exit;
}
$currentUser = $auth->getCurrentUser();
$csrfToken = $auth->generateCSRFToken();
?>
```

**API Authentication:**
```php
<?php
require_once __DIR__ . '/../../includes/api_auth.php';

initializeApiEnvironment();
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
verifyApiAuthentication();
$userInfo = getApiUserInfo();
verifyApiCsrfToken();

api_success($data, 'Success');
api_error('Error', 403);
?>
```

### Frontend CSRF Pattern (MANDATORY)

```javascript
class MyManager {
    getCsrfToken() {
        return document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
    }

    async loadData() {
        const response = await fetch('/CollaboraNexio/api/endpoint.php', {
            method: 'GET',
            credentials: 'same-origin',
            headers: { 'X-CSRF-Token': this.getCsrfToken() }
        });
    }
}
```

### Database Access

```php
$db = Database::getInstance();
$db->insert('users', ['name' => $name]);
$db->update('users', ['status' => 'active'], ['id' => $userId]);
$db->fetchAll('SELECT * FROM users WHERE tenant_id = ? AND deleted_at IS NULL', [$tenantId]);
```

### Transaction Management (CRITICAL)

```php
if (!$db->commit()) {
    if ($db->inTransaction()) {
        $db->rollback();
    }
    api_error('Commit failed', 500);
}

// ALWAYS rollback BEFORE api_error()
if ($validation_fails) {
    if ($db->inTransaction()) { $db->rollback(); }
    api_error('Validation failed', 400);
}
```

### Stored Procedures - PDO OUT Parameters (BUG-129)

```php
// ❌ WRONG
$stmt = $conn->prepare('CALL proc(?, @out1)');

// ✅ CORRECT - 4-step pattern
$conn->exec("SET @p_success = FALSE, @p_message = ''");
$stmt = $conn->prepare('CALL sp_name(?, @p_success, @p_message)');
$stmt->execute([$param1]);
$stmt->closeCursor();  // CRITICAL
$result = $conn->query('SELECT @p_success as success, @p_message as message')->fetch();
```

### API Response Format

```php
// ✅ CORRECT - Wrap arrays in named keys
api_success(['users' => $formattedUsers], 'Success');

// ❌ WRONG
api_success($formattedUsers, 'Success');
```

### Audit Logging (MANDATORY)

```php
try {
    AuditLogger::logDelete($userId, $tenantId, 'file', $fileId, 'File deleted', $oldValues);
} catch (Exception $e) {
    error_log('[AUDIT] ' . $e->getMessage());
    // DO NOT throw
}
```

### OnlyOffice File Validation (BUG-135 v3)

```php
// ✅ CORRECT - Validate file before OnlyOffice operations
$physicalPath = $fileInfo['physical_path'];
$fileExists = file_exists($physicalPath);
$actualSize = $fileExists ? filesize($physicalPath) : 0;

if (!$fileExists) {
    apiError('File fisico non trovato', 404);
}

if ($actualSize === 0) {
    apiError('Il file e vuoto e non puo essere aperto', 400);
}

// ❌ WRONG - Passing empty files to OnlyOffice causes error -4
```

## Code Style

- **Classes:** PascalCase (`Database`, `AuthSimple`)
- **Functions/Methods:** camelCase (`getCurrentUser()`)
- **Variables:** snake_case (`$current_user`)
- **Constants:** UPPER_SNAKE_CASE (`DB_NAME`)
- **Database:** snake_case plural (`users`, `chat_messages`)

## Critical Patterns (MUST FOLLOW)

| Pattern | Bug | Rule |
|---------|-----|------|
| Migration Detection | BUG-156 | Check column existence in information_schema before using optional features in SQL |
| Shared Functions | BUG-155 | NEVER require_once a file with execution logic - extract functions to separate file |
| Ticket Notifications | BUG-154 | Use sendTicketStatusChangedNotification (not legacy) - notifies creator + assigned |
| Closed State UI | BUG-153 | Hide interactive elements when entity state prevents action, show clear notice |
| External Method Calls | BUG-151 | Methods called externally MUST be public (not private static) |
| Workflow Participants | BUG-150b+ | document_workflow has NO validator_name/approver_name - use getSelectedWorkflowParticipants() |
| Email Template Layout | BUG-150a | Use TABLE layout for emails, NOT flexbox (flex/gap not supported by email clients) |
| SELECT vs Array Key | BUG-150b | Array keys MUST match SELECT column names exactly ($file['name'] not $file['file_name']) |
| Deduplicate Actions | BUG-150c | Use array_unique() before returning action arrays to prevent duplicate buttons |
| Workflow Default Check | BUG-149a | Do NOT filter by deleted_at in NOT EXISTS - ANY workflow_roles record means explicitly configured |
| Workflow Default Roles | BUG-149d | Both admin AND manager are default validators/approvers (not just manager) |
| PDO Duplicate Params | BUG-148c | PDO does NOT support duplicate named params - use :param_1, :param_2 or positional ? |
| Workflow Defaults | BUG-148d | Always provide default validator/approver (admin/manager role) when no users configured |
| Ticket Column Name | BUG-147c | Use `first_response_time_minutes` NOT `first_response_time` |
| UNIQUE + Soft Delete | BUG-147c | Remove `deleted_at IS NULL` from MAX when UNIQUE is GLOBAL |
| Workflow is_active | BUG-147b | Always add `AND wr.is_active = 1` when checking workflow_roles |
| JS Async UI Update | BUG-147a | Always await async functions that update UI, show loading indicators |
| PDO Named Params | BUG-146a | PDO does NOT support duplicate named params - use :param_1, :param_2 or positional ? |
| UNIQUE Constraints | BUG-146b | Check if UNIQUE is global or per-tenant before assuming per-tenant uniqueness |
| Files Column Name | BUG-146c | Files table column is `name` NOT `file_name` - use `f.name AS file_name` for alias |
| Database Methods | BUG-145a | Use $db->query() for raw SQL, NOT $db->execute() (execute() doesn't exist) |
| API vs DB Schema | BUG-145b | API validation MUST match database ENUM values exactly |
| DB Schema Validation | BUG-144 | NEVER use users.active_tenant_id (does not exist) or user_companies table (does not exist) |
| DB Column Names | BUG-143 | Verify column names match database schema exactly (check database_errors.log) |
| FK Validation | BUG-142 | ALWAYS validate user IDs exist in same tenant BEFORE insert |
| Task Assignees | BUG-141+142 | Use first VALID assignee as assigned_to, skip invalid/cross-tenant |
| Unified API Endpoint | BUG-140 | Use single /api/{resource}.php with action in body for browser compatibility |
| API Request URL Order | BUG-139 | Use router.php?route= as FIRST URL, direct .php as fallback |
| API Fallback Logic | BUG-138 | Only retry on 404, return app errors (401/403/500) immediately |
| Router Query Params | BUG-137 | API routers MUST check $_GET['route'] BEFORE parsing URL path |
| File Upload Validation | BUG-136 | Verify file size > 0 BOTH before AND after move_uploaded_file() |
| OnlyOffice File Validation | BUG-135 v3 | Validate file exists AND size > 0 before OnlyOffice operations |
| OnlyOffice Docker URLs | BUG-135 v2 | Detect Docker location, not HTTP_HOST. Local Docker = host.docker.internal |
| Promise Error Handling | BUG-134 | Always .catch() async operations in constructors/init |
| JavaScript Event | BUG-132 | Don't use `event` without parameter |
| PDO OUT Params | BUG-129 | SET + CALL + closeCursor + SELECT |
| Soft Delete Check | BUG-127 | Always `AND deleted_at IS NULL` |
| API Routing | BUG-130 | Use `.php` extension explicitly |
| Stored Procedures | BUG-128 | Update after table renames |
| Multi-Tenant | BUG-072 | ALWAYS pass tenant_id in POST |
| CSRF Token | BUG-104 | Include in ALL fetch() calls |
| API Response | BUG-066 | Wrap arrays in named keys |
| OPcache | BUG-070 | Clear after PHP code changes |
| Calendar Privacy | BUG-122 | Filter personal by owner_id |
| Optional Params | BUG-120 | Make ID optional for create/edit |

### Unified API Endpoint Pattern (BUG-140)

```php
// Single endpoint handles ALL operations for a resource
// Bypasses Cloudflare/WAF/CORS issues
// /api/tasks.php

$data = json_decode(file_get_contents('php://input'), true) ?: [];
$action = $data['action'] ?? $_GET['action'] ?? 'list';

switch ($action) {
    case 'list': handleList($db, $userInfo); break;
    case 'create': handleCreate($db, $userInfo, $data); break;
    case 'update': handleUpdate($db, $userInfo, $data); break;
    case 'delete': handleDelete($db, $userInfo, $data); break;
}
```

```javascript
// Frontend: Use unified endpoint with action in body
const url = `/CollaboraNexio/api/tasks.php?_ts=${Date.now()}`;
const body = JSON.stringify({ action: 'create', title: '...' });
const response = await fetch(url, { method: 'POST', body, headers: {...} });
```

### Router Query Parameter Pattern (BUG-137)

```php
// API routers MUST check query parameters FIRST
$path = '';
if (isset($_GET['route']) && !empty($_GET['route'])) {
    // Route passed via query parameter (e.g., router.php?route=tasks/create)
    $path = trim($_GET['route'], '/');
} else {
    // Parse from URL path as fallback
    $path = substr($parsed_path, $pos + strlen($base_path));
}
```

## Database Status

**Last Updated:** 2025-12-15 (post Tenant Roles feature)
**Schema:** 70 BASE TABLES + 9 VIEWS = 79 OBJECTS
**Calendar Tables:** 5 (calendars, calendar_permissions, events, event_participants, event_reminders)
**Ticket Tables:** 6 (tickets, ticket_responses, ticket_assignments, ticket_notifications, ticket_history, ticket_attachments)
**Tenant Roles:** tenant_roles table (13 columns, 2 FKs, 7 indexes) + user_tenant_access.tenant_role_id + tenants.has_custom_roles
**Page Visibility:** 1 table (page_visibility_settings) - 33 records, 8 indexes
**Workflow Roles:** workflow_roles table - 6 records (5 active, 1 soft-deleted), 8 indexes, 3 FKs
**Foreign Keys:** 212 total (+3 tenant_roles: fk_tenant_roles_tenant CASCADE, fk_tenant_roles_created_by SET NULL, fk_user_tenant_access_tenant_role SET NULL)
**Total Indexes:** 438 (+8 tenant_roles)
**Multi-Tenant Compliance:** 100% (0 NULL violations, 0 orphan records)
**Database Size:** ~13.5 MB (healthy: 10-50 MB)
**Stored Objects:** 10 procedures, 4 functions, 1 trigger
**Tables with tenant_id:** 62 (multi-tenant compliant, +1 tenant_roles)
**Tables with deleted_at:** 58 (soft delete compliant, +1 tenant_roles)
**Production Status:** 100% READY (integrity verified 2025-12-15)

## Core Features

### Document Workflow States
```
bozza → in_validazione → validato → in_approvazione → approvato
              ↓ reject                    ↓ reject
           rifiutato ←──────────────────────┘
```

### Calendar System
- 5 tables with full cascade
- RBAC (4-tier permissions)
- Participants with RSVP
- Scheduled reminders
- Email notifications
- Multi-calendar support

### Email Notifications
- Workflow events: 8/9 covered
- Calendar events: 5/5 covered
- Pattern: Non-blocking try-catch

### Page Visibility System
- API: `/api/system/page_visibility.php` (get, save, reset)
- Helper: `/includes/page_visibility_helper.php`
- UI: `configurazioni.php` (Visibilita Pagine tab)
- 11 pages x 3 roles = 33 default settings
- Multi-tenant: tenant_id NULL = global
- super_admin always sees all pages

**Helper Usage:**
```php
require_once __DIR__ . '/includes/page_visibility_helper.php';

// Check visibility
if (isPageVisibleForRole('dashboard', $role, $tenantId)) {
    // Show page
}

// Get all visible pages
$pages = getVisiblePagesForRole($role, $tenantId);

// Check for current session user
if (isPageVisibleForCurrentUser('tasks')) {
    // Show tasks link
}
```

### Tenant Roles System (Ruoli Aziendali)
- API: `/api/tenant-roles/` (list, create, update, delete)
- Table: `tenant_roles` (per-tenant custom business roles)
- Link: `user_tenant_access.tenant_role_id` FK to tenant_roles
- Flag: `tenants.has_custom_roles` (auto-managed)
- Migration: 19_add_tenant_roles.sql
- UI Terminology: "Ruolo" = system role (now "Tipo Utente"), "Ruolo Aziendale" = tenant custom role

**Frontend UI:**
- `utenti.php`: "Tipo Utente" column + "Ruolo Aziendale" column with colored badges
- `aziende.php`: Role management modal with toggle, CRUD table, color picker
- Conditional display: Role dropdown only when tenant has_custom_roles = 1
- Badge contrast: Auto-calculated text color for readability

**API Endpoints:**
```php
// GET list of roles for tenant
GET /api/tenant-roles/list.php?tenant_id={id}&include_inactive=false

// POST create new role
POST /api/tenant-roles/create.php
Body: {tenant_id, name, code?, description?, color?, icon?, sort_order?, is_active?}

// POST update role (code cannot be changed)
POST /api/tenant-roles/update.php
Body: {role_id, name?, description?, color?, icon?, sort_order?, is_active?}

// POST soft delete role
POST /api/tenant-roles/delete.php
Body: {role_id}
```

**User API Extensions:**
```php
// users/create.php - Add tenant_role_id to assign business role
POST /api/users/create.php
Body: {..., tenant_role_id: int}

// users/update.php - Use -1 to remove role, positive int to assign
POST /api/users/update.php
Body: {..., tenant_role_id: int|-1}

// users/list.php - Response includes tenant_role object
Response: {users: [{..., tenant_role: {id, name, code, color, icon}, tenant_role_id}]}
```

**Authorization:**
- list: admin, manager (own tenant), super_admin (any)
- create/update/delete: admin, super_admin only
- Managers can only create users with role='user'

## Documentation Files

- `bug.md` - Recent bugs (last 5)
- `progression.md` - Recent sessions (last 3)
- `bug_archive_20251125.md` - Full bug history
- `progression_archive_20251125.md` - Full progression history

### OnlyOffice Environment Detection (BUG-135 v2+v3)

```php
// CORRECT v2 - Detect WHERE Docker runs (not WHERE request comes from)
$onlyOfficeHost = parse_url(ONLYOFFICE_INTERNAL_URL, PHP_URL_HOST);
$isDockerLocal = ($onlyOfficeHost === 'localhost' || $onlyOfficeHost === '127.0.0.1');
$isServerLocal = (PHP_OS_FAMILY === 'Windows' || stripos(php_uname(), 'microsoft') !== false);

if ($isDockerLocal && $isServerLocal) {
    // Docker is local - ALWAYS use host.docker.internal (even via Cloudflare!)
    define('ONLYOFFICE_DOWNLOAD_URL', 'http://host.docker.internal:8888/...');
} else {
    // Docker is remote - use public BASE_URL
    define('ONLYOFFICE_DOWNLOAD_URL', BASE_URL . '/...');
}

// CORRECT v3 - Validate file before OnlyOffice operations
$actualSize = file_exists($path) ? filesize($path) : 0;
if ($actualSize === 0) {
    apiError('Il file e vuoto', 400);  // Prevents error -4
}

// WRONG - Using HTTP_HOST for Docker URL detection (fails with Cloudflare tunnel)
// $isWindows = (PHP_OS_FAMILY === 'Windows');  // NO!
```

---

**Last Updated:** 2025-12-17 (BUG-155, BUG-156 tenant/users API fixes)
**PHP Version:** 8.3
**Total Bugs Resolved:** 156
**Features Added:** Tenant Roles System (2025-12-15), Ticket Attachment Upload (2025-12-15)
**Previous Fixes:** BUG-046→156 ALL INTACT (zero regression)
**Database Status:** 70 tables, 212 FK (+3 tenant_roles), 100% multi-tenant compliant
**FEATURE (2025-12-15):** Tenant Roles (Ruoli Aziendali) - Companies can define custom roles; Users assigned to roles; Terminology: "Tipo Utente" for system role, "Ruolo Aziendale" for business role
**BUG-156:** Users list API migration compatibility - detect tenant_role_id column before using in queries (api/users/list.php)
**BUG-155:** Tenant update API executing create logic - extract validators to tenant_validators.php, never require_once files with execution logic (3 files fixed)
**BUG-154:** Ticket email notification gap - use sendTicketStatusChangedNotification instead of legacy method in update.php (notifies creator + assigned)
**BUG-153:** Ticket closed reply 403 fix - hide reply section and show notice when ticket is closed (2 files: tickets.js, ticket.php)
**BUG-152:** Ticket attachment upload feature - max 5MB, images/PDF/Word/text, stored in /uploads/tickets/{tenant_id}/, new table ticket_attachments
**BUG-151:** Recall API HTTP 500 (private->public getTenantManagers) + Workflow history empty (get validator/approver names via getSelectedWorkflowParticipants) - 2 files fixed
**BUG-150:** Triple bug fix: (a) email template flexbox->table layout, (b) workflow history `file_name`->`name` column, (c) duplicate recall buttons via array_unique - 3 files fixed
**BUG-149:** Workflow default roles logic - admin AND manager as defaults (149d), NOT EXISTS checks ANY record including soft-deleted (149a) - 2 files fixed
**BUG-148:** Multi-bug fix: ticket.php sidebar (148a), ticket_notification_helper params (148b), PDO duplicate named params in calendar/events (148c), manager as default workflow role (148d) - 6 files fixed
**BUG-147:** Ticket column name fix (first_response_time_minutes) + Workflow is_active filter + Calendar participants race condition (7 files fixed)
**BUG-146:** PDO duplicate named params fix (calendar.php) + Ticket number global uniqueness + Files column `name` not `file_name` (11 files fixed)
**BUG-145:** Workflow HTTP 500 (execute() -> query()) + Ticket HTTP 400 (API urgency validation aligned with DB ENUM)
**BUG-144:** Database schema validation - removed all references to non-existent users.active_tenant_id column and user_companies table (16 files fixed)
**BUG-143:** Column name fix - tasks table uses 'progress_percentage' not 'progress'
**BUG-142:** FK Validation - validate user IDs exist in same tenant BEFORE insert to task_assignments
**BUG-141:** Task assignees display - merged into BUG-142 with user ID validation
**BUG-140:** Unified API endpoint /api/tasks.php - bypasses Cloudflare/CORS/WAF issues
**BUG-139:** API URL order - router.php?route= as FIRST URL, direct .php as fallback
**BUG-138:** API fallback logic - only retry on 404, return app errors immediately
**BUG-137:** Router query parameter fix - router.php now reads $_GET['route'] for fallback routing
**BUG-136:** File upload implementation completed - was stub function returning error
