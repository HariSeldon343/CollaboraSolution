<?php
/**
 * API: Creazione Azienda (Tenant)
 *
 * Endpoint per creare una nuova azienda con tutti i dati completi
 *
 * Method: POST
 * Auth: Admin o Super Admin
 * CSRF: Required
 *
 * @author CollaboraNexio Development Team
 * @version 1.0.0
 */

declare(strict_types=1);

// Inizializza ambiente API
require_once '../../includes/api_auth.php';
initializeApiEnvironment();

// Verifica autenticazione
verifyApiAuthentication();
$userInfo = getApiUserInfo();

// Verifica CSRF token
verifyApiCsrfToken();

// Richiede ruolo Admin o superiore
requireApiRole('admin');

// Carica database
require_once '../../includes/db.php';
$db = Database::getInstance();

// BUG-155 FIX: Carica funzioni di validazione dal file condiviso
// Evita duplicazione codice e conflitti con update.php
require_once __DIR__ . '/tenant_validators.php';

try {
    // Leggi input JSON (body may have been read already by CSRF validation; use cached raw body if present)
    $raw = $GLOBALS['CNX_RAW_BODY'] ?? file_get_contents('php://input');
    $input = json_decode($raw ?: '', true);

    if (!$input || !is_array($input)) {
        // Fallback to form data
        if (!empty($_POST) && is_array($_POST)) {
            $input = $_POST;
        } else {
            apiError('Dati di input non validi', 400);
        }
    }

    // Validazione campi obbligatori
    $errors = [];

    // 1. Denominazione obbligatoria
    if (empty($input['denominazione'])) {
        $errors[] = 'Denominazione azienda obbligatoria';
    }

    // 2. CF OR P.IVA obbligatorio (almeno uno)
    $cf = !empty($input['codice_fiscale']) ? trim($input['codice_fiscale']) : null;
    $piva = !empty($input['partita_iva']) ? trim($input['partita_iva']) : null;

    if (!$cf && !$piva) {
        $errors[] = 'Codice Fiscale o Partita IVA obbligatorio (almeno uno)';
    }

    // Valida CF se presente
    if ($cf && !validateCodiceFiscale($cf)) {
        $errors[] = 'Codice Fiscale non valido (deve essere 16 caratteri alfanumerici)';
    }

    // Valida P.IVA se presente
    if ($piva && !validatePartitaIva($piva)) {
        $errors[] = 'Partita IVA non valida (deve essere 11 cifre con checksum corretto)';
    }

    // Unicità: impedisci duplicati per CF/P.IVA (soft delete aware)
    if ($cf || $piva) {
        $dup = $db->fetchOne(
            "SELECT id, denominazione, codice_fiscale, partita_iva
             FROM tenants
             WHERE deleted_at IS NULL
               AND (
                 (:cf IS NOT NULL AND :cf <> '' AND UPPER(codice_fiscale) = UPPER(:cf))
                 OR
                 (:piva IS NOT NULL AND :piva <> '' AND partita_iva = :piva)
               )
             LIMIT 1",
            [':cf' => $cf, ':piva' => $piva]
        );
        if ($dup) {
            apiError(
                'Esiste già un\'azienda con lo stesso Codice Fiscale o Partita IVA (ID ' . (int)$dup['id'] . ').',
                409,
                ['duplicate_tenant_id' => (int)$dup['id']]
            );
        }
    }

    // 3. Sede legale completa obbligatoria
    if (empty($input['sede_legale'])) {
        $errors[] = 'Sede legale obbligatoria';
    } else {
        $sedeErrors = validateSedeLegale($input['sede_legale']);
        $errors = array_merge($errors, $sedeErrors);
    }

    // 4. Valida sedi operative (opzionale, max 5)
    if (!empty($input['sedi_operative'])) {
        if (!is_array($input['sedi_operative'])) {
            $errors[] = 'Sedi operative deve essere un array';
        } else {
            $sediErrors = validateSediOperative($input['sedi_operative']);
            $errors = array_merge($errors, $sediErrors);
        }
    }

    // 5. Valida manager_id (deve esistere)
    if (!empty($input['manager_id'])) {
        $managerId = (int)$input['manager_id'];

        // Verifica che il manager esista
        $managerExists = $db->exists('users', [
            'id' => $managerId,
            'deleted_at' => null
        ]);

        if (!$managerExists) {
            $errors[] = 'Manager non trovato (ID: ' . $managerId . ')';
        } else {
            // Verifica che il manager abbia il ruolo corretto
            $manager = $db->fetchOne(
                'SELECT role FROM users WHERE id = ? AND deleted_at IS NULL',
                [$managerId]
            );

            if (!in_array($manager['role'], ['manager', 'admin', 'super_admin'])) {
                $errors[] = 'L\'utente selezionato non ha il ruolo di Manager/Admin';
            }
        }
    }

    // 6. Valida email e PEC
    if (!empty($input['email']) && !filter_var($input['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Email non valida';
    }

    if (!empty($input['pec']) && !filter_var($input['pec'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'PEC non valida';
    }

    // 7. Valida telefono
    if (!empty($input['telefono']) && !validateTelefono($input['telefono'])) {
        $errors[] = 'Numero di telefono non valido (formato italiano richiesto)';
    }

    // 8. Valida status
    $validStatuses = ['active', 'inactive', 'suspended'];
    $status = $input['status'] ?? 'active';
    if (!in_array($status, $validStatuses)) {
        $errors[] = 'Status non valido (deve essere: active, inactive, suspended)';
    }

    // Se ci sono errori, restituiscili
    if (!empty($errors)) {
        apiError('Validazione fallita: ' . implode('; ', $errors), 400, ['errors' => $errors]);
    }

    // Prepara i dati per l'inserimento
    $tenantData = [
        'name' => trim($input['denominazione']), // Mantieni compatibilità con campo legacy
        'denominazione' => trim($input['denominazione']),
        'codice_fiscale' => $cf ? strtoupper($cf) : null,
        'partita_iva' => $piva,
        'status' => $status
    ];

    // Sede legale - DEPRECATED: Mantieni per backward compatibility
    if (!empty($input['sede_legale'])) {
        $sede = $input['sede_legale'];
        $tenantData['sede_legale_indirizzo'] = trim($sede['indirizzo']);
        $tenantData['sede_legale_civico'] = trim($sede['civico']);
        $tenantData['sede_legale_comune'] = trim($sede['comune']);
        $tenantData['sede_legale_provincia'] = strtoupper(trim($sede['provincia']));
        $tenantData['sede_legale_cap'] = trim($sede['cap']);
    }

    // Sedi operative - DEPRECATED: Mantieni per backward compatibility
    if (!empty($input['sedi_operative']) && is_array($input['sedi_operative'])) {
        $tenantData['sedi_operative'] = json_encode($input['sedi_operative']);
    }

    // Informazioni aziendali
    if (!empty($input['settore_merceologico'])) {
        $tenantData['settore_merceologico'] = trim($input['settore_merceologico']);
    }

    if (isset($input['numero_dipendenti'])) {
        $tenantData['numero_dipendenti'] = (int)$input['numero_dipendenti'];
    }

    if (isset($input['capitale_sociale'])) {
        $tenantData['capitale_sociale'] = (float)$input['capitale_sociale'];
    }

    // Contatti
    if (!empty($input['telefono'])) {
        $tenantData['telefono'] = trim($input['telefono']);
    }

    if (!empty($input['email'])) {
        $tenantData['email'] = trim($input['email']);
    }

    if (!empty($input['pec'])) {
        $tenantData['pec'] = trim($input['pec']);
    }

    // Manager e rappresentante legale
    if (!empty($input['manager_id'])) {
        $tenantData['manager_id'] = (int)$input['manager_id'];
    }

    if (!empty($input['rappresentante_legale'])) {
        $tenantData['rappresentante_legale'] = trim($input['rappresentante_legale']);
    }

    // Inserimento in transazione
    $db->beginTransaction();

    try {
        // Inserisci il tenant
        $tenantId = $db->insert('tenants', $tenantData);

        // Inserisci sede legale nella nuova tabella tenant_locations
        if (!empty($input['sede_legale'])) {
            $sedeLegale = $input['sede_legale'];

            $db->insert('tenant_locations', [
                'tenant_id' => $tenantId,
                'location_type' => 'sede_legale',
                'indirizzo' => trim($sedeLegale['indirizzo']),
                'civico' => trim($sedeLegale['civico']),
                'cap' => trim($sedeLegale['cap']),
                'comune' => trim($sedeLegale['comune']),
                'provincia' => strtoupper(trim($sedeLegale['provincia'])),
                'telefono' => !empty($sedeLegale['telefono']) ? trim($sedeLegale['telefono']) : null,
                'email' => !empty($sedeLegale['email']) ? trim($sedeLegale['email']) : null,
                'is_primary' => 1,
                'is_active' => 1
            ]);
        }

        // Inserisci sedi operative nella nuova tabella tenant_locations
        if (!empty($input['sedi_operative']) && is_array($input['sedi_operative'])) {
            foreach ($input['sedi_operative'] as $sedeOp) {
                $db->insert('tenant_locations', [
                    'tenant_id' => $tenantId,
                    'location_type' => 'sede_operativa',
                    'indirizzo' => trim($sedeOp['indirizzo']),
                    'civico' => !empty($sedeOp['civico']) ? trim($sedeOp['civico']) : 'SN',
                    'cap' => !empty($sedeOp['cap']) ? trim($sedeOp['cap']) : '00000',
                    'comune' => trim($sedeOp['comune']),
                    'provincia' => !empty($sedeOp['provincia']) ? strtoupper(trim($sedeOp['provincia'])) : 'XX',
                    'telefono' => !empty($sedeOp['telefono']) ? trim($sedeOp['telefono']) : null,
                    'email' => !empty($sedeOp['email']) ? trim($sedeOp['email']) : null,
                    'manager_nome' => !empty($sedeOp['manager_nome']) ? trim($sedeOp['manager_nome']) : null,
                    'note' => !empty($sedeOp['note']) ? trim($sedeOp['note']) : null,
                    'is_primary' => 0,
                    'is_active' => 1
                ]);
            }
        }

        // Log audit
        $db->insert('audit_logs', [
            'tenant_id' => $tenantId,
            'user_id' => $userInfo['user_id'],
            'action' => 'create',
            'entity_type' => 'tenant',
            'entity_id' => $tenantId,
            'new_values' => json_encode([
                'tenant' => $tenantData,
                'locations_created' => (isset($input['sede_legale']) ? 1 : 0) +
                                       (isset($input['sedi_operative']) ? count($input['sedi_operative']) : 0)
            ]),
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null
        ]);

        $db->commit();

        // Risposta di successo
        apiSuccess([
            'tenant_id' => $tenantId,
            'denominazione' => $tenantData['denominazione'],
            'locations_created' => (isset($input['sede_legale']) ? 1 : 0) +
                                   (isset($input['sedi_operative']) ? count($input['sedi_operative']) : 0)
        ], 'Azienda creata con successo');

    } catch (Exception $e) {
        $db->rollback();
        throw $e;
    }

} catch (Exception $e) {
    logApiError('tenants/create', $e);
    apiError('Errore durante la creazione dell\'azienda', 500);
}
